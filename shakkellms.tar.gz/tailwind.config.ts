import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        primary: '#2E7D32',
        'primary-light': '#4CAF50',
        'primary-dark': '#1B5E20',
        accent: '#EBC84C',
        'accent-dark': '#F9A825',
        ink: '#212121',
        'ink-light': '#424242',
        'ink-muted': '#757575',
        cream: '#F8F6F0',
        'cream-dark': '#EEE8DC',
      },
      fontFamily: {
        arabic: ['Noto Kufi Arabic', 'Cairo', 'sans-serif'],
      },
      borderRadius: {
        DEFAULT: '10px',
        lg: '16px',
        xl: '24px',
      },
    },
  },
  plugins: [],
}
export default config
