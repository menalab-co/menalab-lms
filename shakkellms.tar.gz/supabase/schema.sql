-- Shakkel LMS - Full Database Schema
-- Enable necessary extensions
create extension if not exists "uuid-ossp";

-- Users table (extends Supabase auth.users)
create table public.users (
  id uuid references auth.users(id) on delete cascade primary key,
  name text not null,
  email text not null unique,
  avatar text,
  level integer not null default 1,
  xp integer not null default 0,
  ai_credits integer not null default 10,
  max_credits integer not null default 10,
  streak integer not null default 0,
  created_at timestamptz not null default now(),
  last_active timestamptz not null default now()
);

-- Projects table
create table public.projects (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade not null,
  title text not null,
  domain text not null,
  current_stage text not null default 'empathy',
  status text not null default 'active' check (status in ('active', 'completed', 'archived')),
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

-- Project Stages table
create table public.project_stages (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid references public.projects(id) on delete cascade not null,
  stage_name text not null,
  content_viewed boolean not null default false,
  templates_submitted text[] not null default '{}',
  assessment_score integer,
  assessment_passed boolean not null default false,
  unlocked_at timestamptz,
  completed_at timestamptz,
  unique(project_id, stage_name)
);

-- Templates table
create table public.templates (
  id uuid primary key default uuid_generate_v4(),
  name text not null unique,
  title_ar text not null,
  title_en text not null,
  stage text not null,
  fields jsonb not null default '[]',
  icon text,
  description text
);

-- Template Submissions table
create table public.template_submissions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade not null,
  project_id uuid references public.projects(id) on delete cascade not null,
  template_id uuid references public.templates(id) on delete cascade not null,
  data jsonb not null default '{}',
  status text not null default 'draft' check (status in ('draft', 'submitted')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Courses table
create table public.courses (
  id uuid primary key default uuid_generate_v4(),
  title_ar text not null,
  title_en text not null,
  slug text not null unique,
  description text,
  category text not null,
  level text not null,
  price integer not null default 0,
  is_free boolean not null default true,
  ai_credits_included integer not null default 0,
  thumbnail text,
  duration_minutes integer not null default 0,
  instructor_id uuid references public.users(id) on delete set null
);

-- Lessons table
create table public.lessons (
  id uuid primary key default uuid_generate_v4(),
  course_id uuid references public.courses(id) on delete cascade not null,
  title_ar text not null,
  title_en text not null,
  order_index integer not null,
  type text not null default 'video' check (type in ('video', 'text', 'exercise', 'lab')),
  video_url text,
  content_html text,
  xp_reward integer not null default 50,
  duration_minutes integer not null default 0,
  related_templates text[] not null default '{}'
);

-- Enrollments table
create table public.enrollments (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade not null,
  course_id uuid references public.courses(id) on delete cascade not null,
  enrolled_at timestamptz not null default now(),
  completed_at timestamptz,
  credits_granted integer not null default 0,
  payment_status text not null default 'free' check (payment_status in ('free', 'pending', 'paid')),
  unique(user_id, course_id)
);

-- Lesson Progress table
create table public.lesson_progress (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade not null,
  lesson_id uuid references public.lessons(id) on delete cascade not null,
  completed boolean not null default false,
  quiz_score integer,
  completed_at timestamptz,
  unique(user_id, lesson_id)
);

-- Quiz Questions table
create table public.quiz_questions (
  id uuid primary key default uuid_generate_v4(),
  lesson_id uuid references public.lessons(id) on delete cascade,
  stage_name text,
  question_ar text not null,
  type text not null default 'mcq' check (type in ('mcq', 'true_false')),
  options jsonb not null default '[]',
  correct_answer text not null,
  explanation_ar text
);

-- Badges table
create table public.badges (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade not null,
  badge_slug text not null,
  earned_at timestamptz not null default now(),
  unique(user_id, badge_slug)
);

-- Community Posts table
create table public.community_posts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade not null,
  title text not null,
  body text not null,
  tag text,
  votes integer not null default 0,
  solved boolean not null default false,
  created_at timestamptz not null default now()
);

-- Post Replies table
create table public.post_replies (
  id uuid primary key default uuid_generate_v4(),
  post_id uuid references public.community_posts(id) on delete cascade not null,
  user_id uuid references public.users(id) on delete cascade not null,
  text text not null,
  created_at timestamptz not null default now()
);

-- Mentors table
create table public.mentors (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade,
  name text not null,
  title text,
  bio text,
  specialties text[] not null default '{}',
  available boolean not null default true,
  rating numeric(3,2) not null default 5.0,
  session_count integer not null default 0,
  response_time_hours integer not null default 24
);

-- Mentor Requests table
create table public.mentor_requests (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid references public.users(id) on delete cascade not null,
  mentor_id uuid references public.mentors(id) on delete cascade not null,
  type text not null default 'question' check (type in ('question', 'session')),
  content text not null,
  status text not null default 'pending' check (status in ('pending', 'answered', 'accepted', 'declined')),
  reply text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Events table
create table public.events (
  id uuid primary key default uuid_generate_v4(),
  title_ar text not null,
  type text not null check (type in ('webinar', 'meetup', 'workshop', 'competition')),
  date date not null,
  time time,
  host text,
  platform text,
  link text,
  price integer not null default 0,
  is_free boolean not null default true,
  seats integer,
  registered_count integer not null default 0,
  description text,
  tags text[] not null default '{}'
);

-- AI Chat History table
create table public.ai_chat_history (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade not null,
  project_id uuid references public.projects(id) on delete set null,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  created_at timestamptz not null default now()
);

-- ========== INDEXES ==========

create index idx_projects_user_id on public.projects(user_id);
create index idx_project_stages_project_id on public.project_stages(project_id);
create index idx_template_submissions_user_id on public.template_submissions(user_id);
create index idx_template_submissions_project_id on public.template_submissions(project_id);
create index idx_enrollments_user_id on public.enrollments(user_id);
create index idx_lesson_progress_user_id on public.lesson_progress(user_id);
create index idx_badges_user_id on public.badges(user_id);
create index idx_community_posts_user_id on public.community_posts(user_id);
create index idx_ai_chat_history_user_id on public.ai_chat_history(user_id);
create index idx_ai_chat_history_project_id on public.ai_chat_history(project_id);

-- ========== ROW LEVEL SECURITY ==========

alter table public.users enable row level security;
alter table public.projects enable row level security;
alter table public.project_stages enable row level security;
alter table public.templates enable row level security;
alter table public.template_submissions enable row level security;
alter table public.courses enable row level security;
alter table public.lessons enable row level security;
alter table public.enrollments enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.badges enable row level security;
alter table public.community_posts enable row level security;
alter table public.post_replies enable row level security;
alter table public.mentors enable row level security;
alter table public.mentor_requests enable row level security;
alter table public.events enable row level security;
alter table public.ai_chat_history enable row level security;

-- Users policies
create policy "Users can view own profile" on public.users for select using (auth.uid() = id);
create policy "Users can update own profile" on public.users for update using (auth.uid() = id);
create policy "Users can insert own profile" on public.users for insert with check (auth.uid() = id);

-- Projects policies
create policy "Users can view own projects" on public.projects for select using (auth.uid() = user_id);
create policy "Users can insert own projects" on public.projects for insert with check (auth.uid() = user_id);
create policy "Users can update own projects" on public.projects for update using (auth.uid() = user_id);
create policy "Users can delete own projects" on public.projects for delete using (auth.uid() = user_id);

-- Project Stages policies
create policy "Users can view own project stages" on public.project_stages for select
  using (exists (select 1 from public.projects p where p.id = project_id and p.user_id = auth.uid()));
create policy "Users can insert own project stages" on public.project_stages for insert
  with check (exists (select 1 from public.projects p where p.id = project_id and p.user_id = auth.uid()));
create policy "Users can update own project stages" on public.project_stages for update
  using (exists (select 1 from public.projects p where p.id = project_id and p.user_id = auth.uid()));

-- Templates: public read
create policy "Templates are viewable by all" on public.templates for select using (true);

-- Template Submissions policies
create policy "Users can view own submissions" on public.template_submissions for select using (auth.uid() = user_id);
create policy "Users can insert own submissions" on public.template_submissions for insert with check (auth.uid() = user_id);
create policy "Users can update own submissions" on public.template_submissions for update using (auth.uid() = user_id);

-- Courses: public read
create policy "Courses are viewable by all" on public.courses for select using (true);
create policy "Lessons are viewable by all" on public.lessons for select using (true);
create policy "Quiz questions are viewable by all" on public.quiz_questions for select using (true);

-- Enrollments policies
create policy "Users can view own enrollments" on public.enrollments for select using (auth.uid() = user_id);
create policy "Users can insert own enrollments" on public.enrollments for insert with check (auth.uid() = user_id);
create policy "Users can update own enrollments" on public.enrollments for update using (auth.uid() = user_id);

-- Lesson Progress policies
create policy "Users can view own progress" on public.lesson_progress for select using (auth.uid() = user_id);
create policy "Users can insert own progress" on public.lesson_progress for insert with check (auth.uid() = user_id);
create policy "Users can update own progress" on public.lesson_progress for update using (auth.uid() = user_id);

-- Badges policies
create policy "Users can view own badges" on public.badges for select using (auth.uid() = user_id);
create policy "Users can insert own badges" on public.badges for insert with check (auth.uid() = user_id);

-- Community Posts: public read
create policy "Community posts are viewable by all" on public.community_posts for select using (true);
create policy "Users can insert own posts" on public.community_posts for insert with check (auth.uid() = user_id);
create policy "Users can update own posts" on public.community_posts for update using (auth.uid() = user_id);

-- Post Replies: public read
create policy "Post replies are viewable by all" on public.post_replies for select using (true);
create policy "Users can insert own replies" on public.post_replies for insert with check (auth.uid() = user_id);

-- Mentors: public read
create policy "Mentors are viewable by all" on public.mentors for select using (true);

-- Mentor Requests policies
create policy "Students can view own requests" on public.mentor_requests for select
  using (auth.uid() = student_id or exists (select 1 from public.mentors m where m.id = mentor_id and m.user_id = auth.uid()));
create policy "Students can insert requests" on public.mentor_requests for insert with check (auth.uid() = student_id);
create policy "Mentors can update requests" on public.mentor_requests for update
  using (exists (select 1 from public.mentors m where m.id = mentor_id and m.user_id = auth.uid()));

-- Events: public read
create policy "Events are viewable by all" on public.events for select using (true);

-- AI Chat History policies
create policy "Users can view own chat history" on public.ai_chat_history for select using (auth.uid() = user_id);
create policy "Users can insert own chat history" on public.ai_chat_history for insert with check (auth.uid() = user_id);

-- ========== SEED DATA ==========

-- Insert sample templates
insert into public.templates (name, title_ar, title_en, stage, icon, description, fields) values
('empathy_map', 'خريطة التعاطف', 'Empathy Map', 'empathy', '🗺️', 'افهم مستخدمك عمقاً', '[{"name":"thinks","label_ar":"ماذا يفكر؟","type":"textarea"},{"name":"feels","label_ar":"ماذا يشعر؟","type":"textarea"},{"name":"says","label_ar":"ماذا يقول؟","type":"textarea"},{"name":"does","label_ar":"ماذا يفعل؟","type":"textarea"},{"name":"pains","label_ar":"آلامه وتحدياته","type":"textarea"},{"name":"gains","label_ar":"مكاسبه وأهدافه","type":"textarea"}]'),
('user_interview', 'ملاحظات مقابلة المستخدم', 'User Interview Notes', 'empathy', '🎙️', 'وثّق ما تعلمته من المقابلات', '[{"name":"interviewee","label_ar":"المُقابَل (وصف، لا اسم)","type":"text"},{"name":"key_quotes","label_ar":"أهم الاقتباسات","type":"textarea"},{"name":"observations","label_ar":"ملاحظاتك","type":"textarea"},{"name":"insights","label_ar":"الأفكار المستخلصة","type":"textarea"}]'),
('observation_log', 'سجل الملاحظة الميدانية', 'Observation Log', 'empathy', '👁️', 'سجّل ما لاحظته في بيئة المستخدم', '[{"name":"context","label_ar":"السياق والبيئة","type":"textarea"},{"name":"behaviors","label_ar":"السلوكيات الملاحظة","type":"textarea"},{"name":"surprises","label_ar":"ما فاجأك؟","type":"textarea"},{"name":"questions","label_ar":"أسئلة نشأت لديك","type":"textarea"}]'),
('pov_statement', 'عبارة وجهة النظر', 'POV Statement', 'define', '🎯', 'حدد المشكلة الحقيقية', '[{"name":"user","label_ar":"المستخدم (من هو؟)","type":"text"},{"name":"need","label_ar":"يحتاج إلى (ماذا؟)","type":"textarea"},{"name":"insight","label_ar":"لأن (السبب العميق)","type":"textarea"},{"name":"pov","label_ar":"عبارة POV الكاملة","type":"textarea"}]'),
('hmw_questions', 'أسئلة كيف يمكننا؟', 'HMW Questions', 'define', '❓', 'أعد صياغة المشكلة كفرص', '[{"name":"hmw_1","label_ar":"كيف يمكننا... (1)","type":"text"},{"name":"hmw_2","label_ar":"كيف يمكننا... (2)","type":"text"},{"name":"hmw_3","label_ar":"كيف يمكننا... (3)","type":"text"},{"name":"hmw_4","label_ar":"كيف يمكننا... (4)","type":"text"},{"name":"hmw_5","label_ar":"كيف يمكننا... (5)","type":"text"}]'),
('insights_summary', 'ملخص الرؤى', 'Insights Summary', 'define', '💡', 'لخص أهم ما تعلمته', '[{"name":"top_insight","label_ar":"الرؤية الأهم","type":"textarea"},{"name":"patterns","label_ar":"الأنماط التي لاحظتها","type":"textarea"},{"name":"assumptions","label_ar":"الافتراضات التي كسرتها","type":"textarea"}]'),
('brainstorm_canvas', 'لوحة العصف الذهني', 'Brainstorm Canvas', 'ideate', '🧠', 'توليد أكبر عدد من الأفكار', '[{"name":"wild_ideas","label_ar":"أفكار جريئة (لا قيود)","type":"textarea"},{"name":"practical_ideas","label_ar":"أفكار عملية","type":"textarea"},{"name":"borrowed_ideas","label_ar":"أفكار مستوحاة من مجال آخر","type":"textarea"},{"name":"count","label_ar":"عدد الأفكار الإجمالي","type":"text"}]'),
('scamper', 'ورقة SCAMPER', 'SCAMPER Worksheet', 'ideate', '🔧', 'استخدم SCAMPER لتطوير الأفكار', '[{"name":"substitute","label_ar":"استبدل - ماذا يمكن استبداله؟","type":"textarea"},{"name":"combine","label_ar":"دمج - ماذا يمكن دمجه؟","type":"textarea"},{"name":"adapt","label_ar":"تكيّف - ما الذي يمكن تكييفه؟","type":"textarea"},{"name":"modify","label_ar":"عدّل - ماذا يمكن تعديله؟","type":"textarea"},{"name":"eliminate","label_ar":"احذف - ماذا يمكن حذفه؟","type":"textarea"},{"name":"rearrange","label_ar":"رتب - ماذا يمكن إعادة ترتيبه؟","type":"textarea"}]'),
('top_3_ideas', 'أفضل 3 أفكار', 'Top 3 Ideas', 'ideate', '🏆', 'اختر أفضل أفكارك وبررها', '[{"name":"idea_1","label_ar":"الفكرة الأولى","type":"text"},{"name":"why_1","label_ar":"لماذا هذه الفكرة؟","type":"textarea"},{"name":"idea_2","label_ar":"الفكرة الثانية","type":"text"},{"name":"why_2","label_ar":"لماذا هذه الفكرة؟","type":"textarea"},{"name":"idea_3","label_ar":"الفكرة الثالثة","type":"text"},{"name":"why_3","label_ar":"لماذا هذه الفكرة؟","type":"textarea"},{"name":"chosen","label_ar":"الفكرة المختارة للنمذجة","type":"text"}]'),
('prototype_plan', 'خطة النموذج الأولي', 'Prototype Plan', 'prototype', '📐', 'خطط لبناء نموذجك', '[{"name":"type","label_ar":"نوع النموذج (ورقي/رقمي/مادي)","type":"text"},{"name":"features","label_ar":"الميزات الرئيسية للاختبار","type":"textarea"},{"name":"materials","label_ar":"المواد المطلوبة","type":"textarea"},{"name":"timeline","label_ar":"الجدول الزمني","type":"text"}]'),
('materials_list', 'قائمة المواد', 'Materials List', 'prototype', '📋', 'حدد مواد البناء', '[{"name":"materials","label_ar":"المواد (الاسم - الكمية - المصدر)","type":"textarea"},{"name":"tools","label_ar":"الأدوات المطلوبة","type":"textarea"},{"name":"budget","label_ar":"الميزانية التقديرية","type":"text"},{"name":"alternatives","label_ar":"بدائل إن لم تتوفر المواد","type":"textarea"}]'),
('build_log', 'سجل البناء', 'Build Log', 'prototype', '🛠️', 'وثّق عملية البناء', '[{"name":"steps","label_ar":"خطوات البناء التي نفذتها","type":"textarea"},{"name":"challenges","label_ar":"التحديات التي واجهتها","type":"textarea"},{"name":"solutions","label_ar":"كيف حللت المشكلات","type":"textarea"},{"name":"photos_desc","label_ar":"وصف النموذج النهائي","type":"textarea"}]'),
('test_script', 'سكريبت الاختبار', 'Test Script', 'test', '📜', 'جهّز سيناريو اختبار مستخدمك', '[{"name":"goal","label_ar":"هدف الاختبار","type":"textarea"},{"name":"tasks","label_ar":"المهام التي ستطلبها من المستخدم","type":"textarea"},{"name":"questions","label_ar":"أسئلة ستطرحها بعد الاختبار","type":"textarea"},{"name":"metrics","label_ar":"ما الذي ستقيسه؟","type":"textarea"}]'),
('test_results', 'نتائج الاختبار', 'Test Results', 'test', '📊', 'وثّق نتائج اختبارات المستخدمين', '[{"name":"user_1","label_ar":"المستخدم 1: ملاحظات","type":"textarea"},{"name":"user_2","label_ar":"المستخدم 2: ملاحظات","type":"textarea"},{"name":"user_3","label_ar":"المستخدم 3: ملاحظات","type":"textarea"},{"name":"patterns","label_ar":"الأنماط المشتركة","type":"textarea"}]'),
('feedback_summary', 'ملخص التغذية الراجعة', 'Feedback Summary', 'test', '💬', 'لخص ما تعلمته من الاختبار', '[{"name":"what_worked","label_ar":"ما الذي نجح؟","type":"textarea"},{"name":"what_failed","label_ar":"ما الذي لم ينجح؟","type":"textarea"},{"name":"surprises","label_ar":"المفاجآت","type":"textarea"},{"name":"next_steps","label_ar":"الخطوات التالية","type":"textarea"}]'),
('iteration_log', 'سجل التكرار', 'Iteration Log', 'iterate', '🔄', 'وثّق تحسيناتك', '[{"name":"changes","label_ar":"التغييرات التي أجريتها","type":"textarea"},{"name":"why","label_ar":"لماذا هذه التغييرات؟","type":"textarea"},{"name":"result","label_ar":"نتيجة التغييرات","type":"textarea"}]'),
('updated_prototype_plan', 'خطة النموذج المحدث', 'Updated Prototype Plan', 'iterate', '📐', 'خطة النموذج بعد التحسين', '[{"name":"improvements","label_ar":"التحسينات المقررة","type":"textarea"},{"name":"new_features","label_ar":"ميزات جديدة","type":"textarea"},{"name":"removed","label_ar":"ما تمت إزالته","type":"textarea"},{"name":"timeline","label_ar":"الجدول الزمني للتنفيذ","type":"text"}]'),
('final_reflection', 'التأمل النهائي', 'Final Reflection', 'iterate', '🌟', 'تأمل في رحلتك', '[{"name":"journey","label_ar":"كيف تصف رحلتك؟","type":"textarea"},{"name":"learned","label_ar":"أهم ما تعلمته","type":"textarea"},{"name":"would_do_different","label_ar":"ما الذي كنت ستغيره؟","type":"textarea"},{"name":"next_project","label_ar":"مشروعك القادم","type":"textarea"}]');

-- Insert sample courses
insert into public.courses (title_ar, title_en, slug, description, category, level, price, is_free, ai_credits_included, duration_minutes) values
('التفكير التصميمي', 'Design Thinking', 'design-thinking', 'تعلم منهجية التفكير التصميمي من الصفر حتى الاحتراف', 'تصميم', 'مبتدئ', 0, true, 5, 240),
('تصميم CAD بـ Fusion 360', 'CAD with Fusion 360', 'cad-fusion360', 'احترف التصميم ثلاثي الأبعاد باستخدام Fusion 360', 'تصنيع', 'متوسط', 199, false, 10, 480),
('الطباعة ثلاثية الأبعاد', '3D Printing', '3d-printing', 'من الفكرة إلى النموذج المطبوع في 6 دروس', 'تصنيع', 'مبتدئ', 0, true, 3, 180),
('القطع بالليزر', 'Laser Cutting', 'laser-cutting', 'تعلم تشغيل آلة الليزر بأمان واحترافية', 'تصنيع', 'مبتدئ', 99, false, 5, 150),
('الإلكترونيات وArduino', 'Electronics & Arduino', 'arduino-electronics', 'مقدمة في الإلكترونيات والبرمجة مع Arduino', 'تقنية', 'مبتدئ', 0, true, 5, 300),
('تصميم UX/UI', 'UX/UI Design', 'ux-ui-design', 'صمم تجارب مستخدم مذهلة من البحث حتى التسليم', 'تصميم', 'متوسط', 249, false, 8, 420),
('التصنيع بالـ CNC', 'CNC Machining', 'cnc-machining', 'تعلم برمجة وتشغيل ماكينات CNC', 'تصنيع', 'متقدم', 349, false, 10, 360);
