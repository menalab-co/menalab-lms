export const LEVELS = [
  { level: 1, name_ar: 'مستكشف', xp: 0, badge: '🔍' },
  { level: 2, name_ar: 'متعلم', xp: 500, badge: '📚' },
  { level: 3, name_ar: 'صانع', xp: 1500, badge: '🛠️' },
  { level: 4, name_ar: 'مصمم', xp: 3000, badge: '✏️' },
  { level: 5, name_ar: 'مبتكر', xp: 6000, badge: '💡' },
  { level: 6, name_ar: 'رائد', xp: 10000, badge: '🚀' },
  { level: 7, name_ar: 'خبير', xp: 20000, badge: '🏆' },
]

export const XP_REWARDS = {
  lesson_complete: 50,
  template_submit: 25,
  assessment_pass: 75,
  stage_complete: 150,
  course_complete: 500,
  project_complete: 1000,
  community_upvote: 30,
  live_event: 100,
}

export function getLevelFromXP(xp: number): typeof LEVELS[0] {
  let currentLevel = LEVELS[0]
  for (const level of LEVELS) {
    if (xp >= level.xp) {
      currentLevel = level
    } else {
      break
    }
  }
  return currentLevel
}

export function getNextLevel(xp: number): typeof LEVELS[0] | null {
  const current = getLevelFromXP(xp)
  const nextIndex = LEVELS.findIndex(l => l.level === current.level) + 1
  return nextIndex < LEVELS.length ? LEVELS[nextIndex] : null
}

export function getNextLevelXP(xp: number): number {
  const next = getNextLevel(xp)
  return next ? next.xp : LEVELS[LEVELS.length - 1].xp
}

export function getLevelProgress(xp: number): number {
  const current = getLevelFromXP(xp)
  const next = getNextLevel(xp)
  if (!next) return 100
  const range = next.xp - current.xp
  const progress = xp - current.xp
  return Math.min(100, Math.round((progress / range) * 100))
}

export function getXPToNextLevel(xp: number): number {
  const next = getNextLevel(xp)
  if (!next) return 0
  return next.xp - xp
}
