export interface User {
  id: string
  name: string
  email: string
  avatar?: string
  level: number
  xp: number
  ai_credits: number
  max_credits: number
  streak: number
  created_at: string
  last_active: string
}

export interface Project {
  id: string
  user_id: string
  title: string
  domain: string
  current_stage: string
  status: 'active' | 'completed' | 'archived'
  created_at: string
  completed_at?: string
}

export interface ProjectStage {
  id: string
  project_id: string
  stage_name: string
  content_viewed: boolean
  templates_submitted: string[]
  assessment_score?: number
  assessment_passed: boolean
  unlocked_at?: string
  completed_at?: string
}

export interface TemplateField {
  name: string
  label_ar: string
  type: 'text' | 'textarea' | 'select'
  options?: string[]
  required?: boolean
}

export interface Template {
  id: string
  name: string
  title_ar: string
  title_en: string
  stage: string
  fields: TemplateField[]
  icon?: string
  description?: string
}

export interface TemplateSubmission {
  id: string
  user_id: string
  project_id: string
  template_id: string
  data: Record<string, string>
  status: 'draft' | 'submitted'
  created_at: string
  updated_at: string
}

export interface Course {
  id: string
  title_ar: string
  title_en: string
  slug: string
  description?: string
  category: string
  level: string
  price: number
  is_free: boolean
  ai_credits_included: number
  thumbnail?: string
  duration_minutes: number
  instructor_id?: string
}

export interface Lesson {
  id: string
  course_id: string
  title_ar: string
  title_en: string
  order_index: number
  type: 'video' | 'text' | 'exercise' | 'lab'
  video_url?: string
  content_html?: string
  xp_reward: number
  duration_minutes: number
  related_templates: string[]
}

export interface Enrollment {
  id: string
  user_id: string
  course_id: string
  enrolled_at: string
  completed_at?: string
  credits_granted: number
  payment_status: 'free' | 'pending' | 'paid'
}

export interface LessonProgress {
  id: string
  user_id: string
  lesson_id: string
  completed: boolean
  quiz_score?: number
  completed_at?: string
}

export interface QuizQuestion {
  id: string
  lesson_id?: string
  stage_name?: string
  question_ar: string
  type: 'mcq' | 'true_false'
  options: string[]
  correct_answer: string
  explanation_ar?: string
}

export interface Badge {
  id: string
  user_id: string
  badge_slug: string
  earned_at: string
}

export interface CommunityPost {
  id: string
  user_id: string
  title: string
  body: string
  tag?: string
  votes: number
  solved: boolean
  created_at: string
}

export interface PostReply {
  id: string
  post_id: string
  user_id: string
  text: string
  created_at: string
}

export interface Mentor {
  id: string
  user_id?: string
  name: string
  title?: string
  bio?: string
  specialties: string[]
  available: boolean
  rating: number
  session_count: number
  response_time_hours: number
}

export interface MentorRequest {
  id: string
  student_id: string
  mentor_id: string
  type: 'question' | 'session'
  content: string
  status: 'pending' | 'answered' | 'accepted' | 'declined'
  reply?: string
  created_at: string
  updated_at: string
}

export interface Event {
  id: string
  title_ar: string
  type: 'webinar' | 'meetup' | 'workshop' | 'competition'
  date: string
  time?: string
  host?: string
  platform?: string
  link?: string
  price: number
  is_free: boolean
  seats?: number
  registered_count: number
  description?: string
  tags: string[]
}

export interface AIChatMessage {
  id: string
  user_id: string
  project_id?: string
  role: 'user' | 'assistant'
  content: string
  created_at: string
}

export type StageKey = 'empathy' | 'define' | 'ideate' | 'prototype' | 'test' | 'iterate'

export const STAGE_NAMES_AR: Record<StageKey, string> = {
  empathy: 'التعاطف',
  define: 'تحديد المشكلة',
  ideate: 'توليد الأفكار',
  prototype: 'النموذج',
  test: 'الاختبار',
  iterate: 'التطوير',
}

export const STAGE_ICONS: Record<StageKey, string> = {
  empathy: '🗺️',
  define: '🎯',
  ideate: '💡',
  prototype: '🛠️',
  test: '🧪',
  iterate: '🔄',
}

export const STAGE_ORDER: StageKey[] = ['empathy', 'define', 'ideate', 'prototype', 'test', 'iterate']

export const STAGE_TEMPLATES: Record<StageKey, string[]> = {
  empathy: ['empathy_map', 'user_interview', 'observation_log'],
  define: ['pov_statement', 'hmw_questions', 'insights_summary'],
  ideate: ['brainstorm_canvas', 'scamper', 'top_3_ideas'],
  prototype: ['prototype_plan', 'materials_list', 'build_log'],
  test: ['test_script', 'test_results', 'feedback_summary'],
  iterate: ['iteration_log', 'updated_prototype_plan', 'final_reflection'],
}

export const BADGE_DEFINITIONS = [
  { slug: 'empathy_expert', name_ar: 'خبير التعاطف', icon: '🗺️', description: 'أكملت مرحلة التعاطف' },
  { slug: 'problem_definer', name_ar: 'محدد المشكلة', icon: '🎯', description: 'أكملت مرحلة تحديد المشكلة' },
  { slug: 'idea_generator', name_ar: 'مولّد الأفكار', icon: '💡', description: 'أكملت مرحلة توليد الأفكار' },
  { slug: 'builder', name_ar: 'بانٍ', icon: '🛠️', description: 'أكملت مرحلة النمذجة' },
  { slug: 'tester', name_ar: 'مختبِر', icon: '🧪', description: 'أكملت مرحلة الاختبار' },
  { slug: 'iteratorer', name_ar: 'مكرِّر', icon: '🔄', description: 'أكملت دورة التفكير التصميمي كاملة' },
  { slug: '3d_printer', name_ar: 'طابع ثلاثي', icon: '🖨️', description: 'أكملت دورة الطباعة ثلاثية الأبعاد' },
  { slug: 'cad_engineer', name_ar: 'مهندس CAD', icon: '⚙️', description: 'أكملت دورة Fusion 360' },
  { slug: 'laser_pro', name_ar: 'ليزر', icon: '🔆', description: 'أكملت دورة القطع بالليزر' },
  { slug: 'community_builder', name_ar: 'صانع مجتمع', icon: '🤝', description: '10 إجابات نالت تصويتاً إيجابياً' },
]
