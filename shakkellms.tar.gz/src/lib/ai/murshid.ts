import Anthropic from '@anthropic-ai/sdk'
import { findLocalAnswer } from './localQA'
import { STAGE_NAMES_AR } from '../types'
import type { StageKey } from '../types'

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

export interface MurshidContext {
  stage?: StageKey
  lastAction?: string
  daysSinceVisit?: number
  projectTitle?: string
  userName?: string
}

export interface MurshidResponse {
  message: string
  usedCredits: boolean
}

const MURSHID_SYSTEM_PROMPT = `أنت "مرشد" - مساعد التعلم الذكي في منصة شكّل للتفكير التصميمي والتصنيع.

شخصيتك:
- مشجع ودافئ، تؤمن بقدرات الطالب دائماً
- عملي ومحدد، تعطي خطوات واضحة لا نصائح عامة
- تستخدم عربية بسيطة وواضحة، وتتجنب المصطلحات المعقدة
- تذكر دائماً أن الطالب يتعلم التفكير التصميمي والتصنيع

قواعد الإجابة:
- أجب باللغة العربية دائماً
- اجعل إجابتك مختصرة (3-5 جمل عادةً)
- قدم خطوة تالية واحدة واضحة
- لا تقل "أنا لا أعرف" - قدم أفضل ما عندك
- استخدم الـ emoji باعتدال لإضفاء الدفء`

export const PROACTIVE_MESSAGES = {
  stageEntry: (stage: StageKey): string => {
    const stageName = STAGE_NAMES_AR[stage]
    const messages: Record<StageKey, string> = {
      empathy: `مرحباً بك في مرحلة التعاطف! 🗺️ هنا ستتعرف على مستخدمك بعمق. ابدأ بخريطة التعاطف لتفهم ما يفكر فيه ويشعر به. خذ وقتك في هذه المرحلة - كل ثانية تقضيها هنا توفر ساعات من العمل الخاطئ لاحقاً.`,
      define: `أهلاً بك في مرحلة تحديد المشكلة! 🎯 الآن بعد أن فهمت مستخدمك، حان وقت صياغة المشكلة بدقة. عبارة POV الجيدة ستكون دليلك طوال المشروع.`,
      ideate: `ابدأ رحلة الإبداع! 💡 في هذه المرحلة، أكثر الأفكار = أفضل. لا تحكم على أي فكرة الآن. جرب تقنية SCAMPER لتوليد أفكار مبتكرة.`,
      prototype: `حان وقت البناء! 🛠️ ابدأ بنموذج بسيط - ورقة وقلم يكفيان في البداية. الهدف هو تجسيد فكرتك بأسرع وقت لتتعلم منها.`,
      test: `مرحلة الاختبار هنا! 🧪 حضّر 3 مستخدمين على الأقل. أعطهم مهام محددة وراقب ردود أفعالهم. الصمت أثناء الاختبار هو صديقك.`,
      iterate: `التكرار هو سر النجاح! 🔄 بناءً على ما تعلمته من الاختبار، طوّر نموذجك. كل تكرار يقربك من الحل المثالي.`,
    }
    return messages[stage] || `مرحباً بك في مرحلة ${stageName}!`
  },

  templateNotSubmitted: (templateName: string): string =>
    `لاحظت أن قالب "${templateName}" لم يُسلَّم بعد منذ يوم. 📝 لا تقلق، يمكنك حفظه كمسودة والعودة إليه. هل تحتاج مساعدة في ملئه؟`,

  assessmentFailed: (score: number): string =>
    `لا بأس بالمحاولة الأولى! 💪 حصلت على ${score}%. راجع المحتوى التعليمي مرة أخرى، وركز على الأسئلة التي أخطأت فيها. أنت أقرب مما تظن!`,

  beforeAssessment: (): string =>
    `على وشك اجتياز التقييم! 🎯 تذكر: اقرأ كل سؤال بعناية، وثق بما تعلمته. نسبة النجاح 90%، لكنك جاهز لذلك. بالتوفيق!`,

  templateSubmitted: (templateName: string): string =>
    `ممتاز! قالب "${templateName}" سُلِّم بنجاح. ✅ هذا تقدم حقيقي. هل تريد الانتقال للقالب التالي؟`,

  stageUnlocked: (stage: StageKey): string => {
    const stageName = STAGE_NAMES_AR[stage]
    return `🎉 تهانيّ! فتحت مرحلة "${stageName}" الجديدة! لقد أثبتت تمكنك من المرحلة السابقة. الرحلة تزداد عمقاً وإثارة من هنا!`
  },

  idleHint: (daysSinceVisit: number, stage?: StageKey): string => {
    const stageName = stage ? STAGE_NAMES_AR[stage] : 'مشروعك'
    return `مرحباً! مضت ${daysSinceVisit} أيام على آخر زيارة. 👋 ${stageName} ينتظرك! حتى 15 دقيقة الآن ستصنع فرقاً. عد ونكمل معاً!`
  },
}

export async function askMurshid(
  question: string,
  context: MurshidContext = {},
  userId?: string
): Promise<MurshidResponse> {
  // Try local Q&A first
  const localAnswer = findLocalAnswer(question)
  if (localAnswer) {
    return { message: localAnswer, usedCredits: false }
  }

  // Fall back to Claude API
  try {
    const contextStr = context.stage
      ? `\nسياق إضافي: الطالب في مرحلة ${STAGE_NAMES_AR[context.stage]} من التفكير التصميمي.${context.projectTitle ? ` اسم المشروع: ${context.projectTitle}.` : ''}${context.userName ? ` اسم الطالب: ${context.userName}.` : ''}`
      : ''

    const message = await client.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 500,
      system: MURSHID_SYSTEM_PROMPT + contextStr,
      messages: [{ role: 'user', content: question }],
    })

    const responseText =
      message.content[0].type === 'text' ? message.content[0].text : 'عذراً، حدث خطأ. حاول مرة أخرى.'

    return { message: responseText, usedCredits: true }
  } catch (error) {
    console.error('Murshid API error:', error)
    return {
      message:
        'عذراً، مرشد غير متاح الآن. يمكنك مراجعة المحتوى التعليمي أو تصفح مجتمع شكّل للحصول على مساعدة.',
      usedCredits: false,
    }
  }
}

export async function getMurshidProactiveMessage(
  trigger: 'stage_entry' | 'template_not_submitted' | 'assessment_failed' | 'before_assessment' | 'template_submitted' | 'stage_unlocked' | 'idle',
  data: {
    stage?: StageKey
    templateName?: string
    score?: number
    daysSinceVisit?: number
  }
): Promise<string> {
  switch (trigger) {
    case 'stage_entry':
      return data.stage ? PROACTIVE_MESSAGES.stageEntry(data.stage) : 'مرحباً بك!'
    case 'template_not_submitted':
      return data.templateName ? PROACTIVE_MESSAGES.templateNotSubmitted(data.templateName) : ''
    case 'assessment_failed':
      return PROACTIVE_MESSAGES.assessmentFailed(data.score || 0)
    case 'before_assessment':
      return PROACTIVE_MESSAGES.beforeAssessment()
    case 'template_submitted':
      return data.templateName ? PROACTIVE_MESSAGES.templateSubmitted(data.templateName) : ''
    case 'stage_unlocked':
      return data.stage ? PROACTIVE_MESSAGES.stageUnlocked(data.stage) : ''
    case 'idle':
      return PROACTIVE_MESSAGES.idleHint(data.daysSinceVisit || 2, data.stage)
    default:
      return 'مرحباً! كيف يمكنني مساعدتك اليوم؟'
  }
}
