'use client'

import type { Template, TemplateSubmission } from '@/lib/types'
import Badge from '../ui/Badge'

interface TemplateCardProps {
  template: Template
  submission?: TemplateSubmission
  onOpen: (template: Template) => void
}

export default function TemplateCard({ template, submission, onOpen }: TemplateCardProps) {
  const status = submission?.status || 'empty'

  return (
    <div
      className={`bg-white border-2 rounded-xl p-5 cursor-pointer hover:shadow-md transition-all ${
        status === 'submitted'
          ? 'border-green-300 bg-green-50/30'
          : status === 'draft'
          ? 'border-accent/50'
          : 'border-cream-dark hover:border-primary/50'
      }`}
      onClick={() => onOpen(template)}
      dir="rtl"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-2xl">{template.icon}</span>
          <div>
            <h4 className="font-bold text-ink">{template.title_ar}</h4>
            <p className="text-xs text-ink-muted">{template.description}</p>
          </div>
        </div>
        <Badge
          variant={status === 'submitted' ? 'success' : status === 'draft' ? 'warning' : 'neutral'}
          size="sm"
        >
          {status === 'submitted' ? '✓ مُسلَّم' : status === 'draft' ? 'مسودة' : 'لم يُملأ'}
        </Badge>
      </div>
      <div className="flex items-center gap-2 text-xs text-ink-muted">
        <span>{template.fields.length} حقل</span>
        <span>•</span>
        <span className="text-primary font-medium">اضغط للفتح</span>
      </div>
    </div>
  )
}
