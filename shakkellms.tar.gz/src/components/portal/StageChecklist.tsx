interface ChecklistItem {
  label: string
  done: boolean
}

interface StageChecklistProps {
  items: ChecklistItem[]
  canUnlock: boolean
  onNext?: () => void
}

export default function StageChecklist({ items, canUnlock, onNext }: StageChecklistProps) {
  const allDone = items.every(i => i.done)

  return (
    <div className="bg-white border border-cream-dark rounded-xl p-5" dir="rtl">
      <h3 className="font-bold text-ink mb-4">قائمة متطلبات المرحلة</h3>
      <div className="space-y-3 mb-4">
        {items.map((item, i) => (
          <div key={i} className="flex items-center gap-3">
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${
              item.done ? 'bg-green-500 text-white' : 'bg-cream-dark text-ink-muted'
            }`}>
              {item.done ? '✓' : i + 1}
            </div>
            <span className={`text-sm ${item.done ? 'text-ink line-through opacity-60' : 'text-ink'}`}>
              {item.label}
            </span>
          </div>
        ))}
      </div>
      {canUnlock && onNext && (
        <button
          onClick={onNext}
          className="w-full bg-primary text-white py-3 rounded-[10px] font-bold hover:bg-primary-dark transition-colors"
        >
          المرحلة التالية ←
        </button>
      )}
      {!canUnlock && (
        <p className="text-center text-sm text-ink-muted bg-cream rounded-[10px] py-3">
          أكمل جميع المتطلبات لفتح المرحلة التالية
        </p>
      )}
    </div>
  )
}
