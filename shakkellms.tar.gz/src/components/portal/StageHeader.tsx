import { STAGE_NAMES_AR, STAGE_ICONS, STAGE_ORDER } from '@/lib/types'
import type { StageKey } from '@/lib/types'

interface StageHeaderProps {
  stage: StageKey
  projectTitle: string
  stageIndex: number
}

export default function StageHeader({ stage, projectTitle, stageIndex }: StageHeaderProps) {
  return (
    <div className="bg-gradient-to-l from-primary to-primary-dark text-white rounded-xl p-6 mb-6" dir="rtl">
      <div className="flex items-center gap-3 mb-3">
        <span className="text-3xl">{STAGE_ICONS[stage]}</span>
        <div>
          <p className="text-white/70 text-sm">
            المرحلة {stageIndex + 1} من {STAGE_ORDER.length} — {projectTitle}
          </p>
          <h2 className="text-2xl font-bold">{STAGE_NAMES_AR[stage]}</h2>
        </div>
      </div>
      <div className="flex gap-2 mt-4">
        {STAGE_ORDER.map((s, i) => (
          <div
            key={s}
            className={`h-1.5 flex-1 rounded-full transition-all ${
              i < stageIndex ? 'bg-white' :
              i === stageIndex ? 'bg-accent' :
              'bg-white/30'
            }`}
            title={STAGE_NAMES_AR[s]}
          />
        ))}
      </div>
    </div>
  )
}
