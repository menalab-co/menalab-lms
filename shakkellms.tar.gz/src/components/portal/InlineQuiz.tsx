'use client'

import { useState } from 'react'
import type { QuizQuestion } from '@/lib/types'
import Button from '../ui/Button'

interface InlineQuizProps {
  questions: QuizQuestion[]
  onPass: (score: number) => void
  onFail: (score: number) => void
  alreadyPassed?: boolean
  lastScore?: number
}

export default function InlineQuiz({ questions, onPass, onFail, alreadyPassed, lastScore }: InlineQuizProps) {
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [submitted, setSubmitted] = useState(false)
  const [score, setScore] = useState(0)
  const [currentQ, setCurrentQ] = useState(0)

  if (alreadyPassed) {
    return (
      <div className="bg-green-50 border-2 border-green-300 rounded-xl p-6 text-center" dir="rtl">
        <div className="text-4xl mb-3">🎉</div>
        <h3 className="font-bold text-green-800 text-xl mb-1">اجتزت التقييم!</h3>
        <p className="text-green-700">نتيجتك: {lastScore}%</p>
      </div>
    )
  }

  function selectAnswer(questionId: string, answer: string) {
    if (submitted) return
    setAnswers((prev) => ({ ...prev, [questionId]: answer }))
  }

  function handleSubmit() {
    if (Object.keys(answers).length < questions.length) return

    let correct = 0
    questions.forEach((q) => {
      if (answers[q.id] === q.correct_answer) correct++
    })

    const pct = Math.round((correct / questions.length) * 100)
    setScore(pct)
    setSubmitted(true)

    if (pct >= 90) onPass(pct)
    else onFail(pct)
  }

  function handleRetry() {
    setAnswers({})
    setSubmitted(false)
    setScore(0)
    setCurrentQ(0)
  }

  if (submitted) {
    const passed = score >= 90
    return (
      <div className={`border-2 rounded-xl p-6 text-center ${passed ? 'bg-green-50 border-green-300' : 'bg-red-50 border-red-300'}`} dir="rtl">
        <div className="text-5xl mb-3">{passed ? '🎉' : '😔'}</div>
        <h3 className={`font-bold text-xl mb-2 ${passed ? 'text-green-800' : 'text-red-800'}`}>
          {passed ? 'ممتاز! اجتزت التقييم!' : 'لم تنجح هذه المرة'}
        </h3>
        <p className={`mb-4 text-lg font-bold ${passed ? 'text-green-700' : 'text-red-700'}`}>
          نتيجتك: {score}%
        </p>
        {!passed && (
          <>
            <p className="text-red-600 text-sm mb-4">تحتاج 90% أو أكثر للنجاح. راجع المحتوى وحاول مرة أخرى.</p>
            <div className="text-right mb-4 space-y-3">
              {questions.map((q) => {
                const userAns = answers[q.id]
                const correct = userAns === q.correct_answer
                return (
                  <div key={q.id} className={`p-3 rounded-[10px] text-sm text-right ${correct ? 'bg-green-100' : 'bg-red-100'}`}>
                    <p className="font-medium mb-1">{correct ? '✓' : '✗'} {q.question_ar}</p>
                    {!correct && q.explanation_ar && (
                      <p className="text-ink-muted text-xs">{q.explanation_ar}</p>
                    )}
                  </div>
                )
              })}
            </div>
            <Button onClick={handleRetry} variant="outline">حاول مرة أخرى</Button>
          </>
        )}
      </div>
    )
  }

  const q = questions[currentQ]
  if (!q) return null

  return (
    <div className="bg-white border border-cream-dark rounded-xl p-6" dir="rtl">
      {/* Progress dots */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-1.5">
          {questions.map((_, i) => (
            <div
              key={i}
              className={`w-2.5 h-2.5 rounded-full transition-all ${
                i < currentQ ? 'bg-primary' :
                i === currentQ ? 'bg-accent' :
                'bg-cream-dark'
              }`}
            />
          ))}
        </div>
        <span className="text-sm text-ink-muted">{currentQ + 1} / {questions.length}</span>
      </div>

      <h3 className="font-bold text-ink text-lg mb-5">{q.question_ar}</h3>

      <div className="space-y-3 mb-6">
        {q.options.map((option, i) => (
          <button
            key={i}
            onClick={() => selectAnswer(q.id, option)}
            className={`w-full text-right px-5 py-3.5 rounded-[10px] border-2 transition-all text-sm font-medium ${
              answers[q.id] === option
                ? 'border-primary bg-primary/10 text-primary'
                : 'border-cream-dark hover:border-primary/50 text-ink'
            }`}
          >
            {option}
          </button>
        ))}
      </div>

      <div className="flex justify-between">
        {currentQ > 0 ? (
          <Button variant="ghost" size="sm" onClick={() => setCurrentQ(c => c - 1)}>← السابق</Button>
        ) : <div />}

        {currentQ < questions.length - 1 ? (
          <Button
            size="sm"
            disabled={!answers[q.id]}
            onClick={() => setCurrentQ(c => c + 1)}
          >
            التالي →
          </Button>
        ) : (
          <Button
            disabled={Object.keys(answers).length < questions.length}
            onClick={handleSubmit}
          >
            تسليم الإجابات
          </Button>
        )}
      </div>
    </div>
  )
}
