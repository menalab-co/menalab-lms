'use client'

import { useState, useEffect } from 'react'
import Modal from '../ui/Modal'
import Button from '../ui/Button'
import type { Template, TemplateSubmission } from '@/lib/types'
import { createClient } from '@/lib/supabase/client'

interface TemplateModalProps {
  template: Template | null
  submission?: TemplateSubmission
  projectId: string
  onClose: () => void
  onSubmitted: (templateName: string) => void
}

export default function TemplateModal({ template, submission, projectId, onClose, onSubmitted }: TemplateModalProps) {
  const [formData, setFormData] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle')

  useEffect(() => {
    if (submission?.data) {
      setFormData(submission.data)
    } else {
      setFormData({})
    }
  }, [submission, template])

  async function handleFieldChange(name: string, value: string) {
    const newData = { ...formData, [name]: value }
    setFormData(newData)

    // Auto-save draft
    setSaveStatus('saving')
    const supabase = createClient()
    const { data: { session } } = await supabase.auth.getSession()
    if (!session || !template) return

    if (submission) {
      await supabase
        .from('template_submissions')
        .update({ data: newData, updated_at: new Date().toISOString() })
        .eq('id', submission.id)
    } else {
      await supabase.from('template_submissions').upsert({
        user_id: session.user.id,
        project_id: projectId,
        template_id: template.id,
        data: newData,
        status: 'draft',
      })
    }
    setSaveStatus('saved')
    setTimeout(() => setSaveStatus('idle'), 2000)
  }

  async function handleSubmit() {
    if (!template) return
    setSubmitting(true)
    const supabase = createClient()
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) return

    if (submission) {
      await supabase
        .from('template_submissions')
        .update({ data: formData, status: 'submitted', updated_at: new Date().toISOString() })
        .eq('id', submission.id)
    } else {
      await supabase.from('template_submissions').insert({
        user_id: session.user.id,
        project_id: projectId,
        template_id: template.id,
        data: formData,
        status: 'submitted',
      })
    }

    setSubmitting(false)
    onSubmitted(template.name)
    onClose()
  }

  const isReadOnly = submission?.status === 'submitted'

  if (!template) return null

  return (
    <Modal open={!!template} onClose={onClose} title={template.title_ar} size="lg">
      <div className="p-6" dir="rtl">
        {isReadOnly && (
          <div className="bg-green-50 border border-green-200 text-green-700 rounded-[10px] p-3 mb-4 text-sm">
            ✅ تم تسليم هذا القالب. يمكنك مراجعته بدون تعديل.
          </div>
        )}

        <div className="space-y-5">
          {template.fields.map((field) => (
            <div key={field.name}>
              <label className="block text-sm font-semibold text-ink mb-1.5">
                {field.label_ar}
              </label>
              {field.type === 'textarea' ? (
                <textarea
                  value={formData[field.name] || ''}
                  onChange={(e) => handleFieldChange(field.name, e.target.value)}
                  disabled={isReadOnly}
                  rows={3}
                  className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary focus:bg-white transition-colors resize-none disabled:opacity-60"
                />
              ) : (
                <input
                  type="text"
                  value={formData[field.name] || ''}
                  onChange={(e) => handleFieldChange(field.name, e.target.value)}
                  disabled={isReadOnly}
                  className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary focus:bg-white transition-colors disabled:opacity-60"
                />
              )}
            </div>
          ))}
        </div>

        {!isReadOnly && (
          <div className="flex items-center justify-between mt-6 pt-4 border-t border-cream-dark">
            <span className="text-xs text-ink-muted">
              {saveStatus === 'saving' ? '⏳ جارٍ الحفظ...' : saveStatus === 'saved' ? '✅ حُفظ' : ''}
            </span>
            <div className="flex gap-3">
              <Button variant="outline" onClick={onClose}>إغلاق</Button>
              <Button onClick={handleSubmit} loading={submitting}>
                تسليم القالب ✓
              </Button>
            </div>
          </div>
        )}
        {isReadOnly && (
          <div className="mt-6 pt-4 border-t border-cream-dark flex justify-end">
            <Button variant="outline" onClick={onClose}>إغلاق</Button>
          </div>
        )}
      </div>
    </Modal>
  )
}
