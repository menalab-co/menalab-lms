import type { StageKey } from '@/lib/types'
import { STAGE_NAMES_AR } from '@/lib/types'

interface StageUnlockBannerProps {
  stage: StageKey
}

export default function StageUnlockBanner({ stage }: StageUnlockBannerProps) {
  return (
    <div className="bg-gradient-to-l from-accent to-accent-dark text-ink rounded-xl p-6 text-center" dir="rtl">
      <div className="text-4xl mb-3">🎉</div>
      <h3 className="text-xl font-bold mb-2">تهانيّ! فتحت مرحلة جديدة</h3>
      <p className="text-ink-light">مرحباً بك في مرحلة <strong>{STAGE_NAMES_AR[stage]}</strong>!</p>
    </div>
  )
}
