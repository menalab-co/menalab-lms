'use client'

import Link from 'next/link'
import { useState } from 'react'

interface HeaderProps {
  isLoggedIn?: boolean
  userName?: string
}

export default function Header({ isLoggedIn = false, userName }: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <header className="bg-white border-b border-cream-dark sticky top-0 z-40" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl font-bold text-primary">شكّل</span>
            <span className="text-xs text-ink-muted hidden sm:block">منصة التفكير التصميمي</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-ink-light hover:text-primary font-medium transition-colors">الرئيسية</Link>
            <Link href="/courses" className="text-ink-light hover:text-primary font-medium transition-colors">الدورات</Link>
            <Link href="/mentors" className="text-ink-light hover:text-primary font-medium transition-colors">المرشدون</Link>
            <Link href="/community" className="text-ink-light hover:text-primary font-medium transition-colors">المجتمع</Link>
          </nav>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center gap-3">
            {isLoggedIn ? (
              <>
                <Link href="/dashboard" className="flex items-center gap-2 text-sm text-ink-light hover:text-primary">
                  <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-sm font-bold">
                    {userName?.[0] || 'م'}
                  </div>
                  <span>{userName || 'المستخدم'}</span>
                </Link>
              </>
            ) : (
              <>
                <Link href="/login" className="text-ink-light hover:text-primary font-medium transition-colors text-sm px-4 py-2">
                  تسجيل الدخول
                </Link>
                <Link
                  href="/signup"
                  className="bg-primary text-white px-4 py-2 rounded-[10px] text-sm font-semibold hover:bg-primary-dark transition-colors"
                >
                  ابدأ مجاناً
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden text-ink p-2"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <span className="text-xl">{menuOpen ? '✕' : '☰'}</span>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-white border-t border-cream-dark px-4 py-4 flex flex-col gap-4">
          <Link href="/" className="text-ink font-medium" onClick={() => setMenuOpen(false)}>الرئيسية</Link>
          <Link href="/courses" className="text-ink font-medium" onClick={() => setMenuOpen(false)}>الدورات</Link>
          <Link href="/mentors" className="text-ink font-medium" onClick={() => setMenuOpen(false)}>المرشدون</Link>
          <Link href="/community" className="text-ink font-medium" onClick={() => setMenuOpen(false)}>المجتمع</Link>
          {!isLoggedIn && (
            <div className="flex flex-col gap-2 pt-2 border-t border-cream-dark">
              <Link href="/login" className="text-center py-2 border border-primary text-primary rounded-[10px]">تسجيل الدخول</Link>
              <Link href="/signup" className="text-center py-2 bg-primary text-white rounded-[10px]">ابدأ مجاناً</Link>
            </div>
          )}
        </div>
      )}
    </header>
  )
}
