import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-ink text-white" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-2xl font-bold text-accent mb-3">شكّل</h3>
            <p className="text-gray-400 text-sm leading-relaxed max-w-xs">
              منصة التفكير التصميمي والتصنيع. تعلّم، ابتكر، وابنِ حلولاً حقيقية لمشاكل حقيقية.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">المنصة</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="/courses" className="hover:text-accent transition-colors">الدورات</Link></li>
              <li><Link href="/mentors" className="hover:text-accent transition-colors">المرشدون</Link></li>
              <li><Link href="/community" className="hover:text-accent transition-colors">المجتمع</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">الشركة</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="#" className="hover:text-accent transition-colors">من نحن</Link></li>
              <li><Link href="#" className="hover:text-accent transition-colors">سياسة الخصوصية</Link></li>
              <li><Link href="#" className="hover:text-accent transition-colors">تواصل معنا</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-500">
          <p>© 2024 شكّل. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  )
}
