'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { clsx } from 'clsx'

interface SidebarLink {
  href: string
  icon: string
  label: string
}

const LINKS: SidebarLink[] = [
  { href: '/dashboard', icon: '🏠', label: 'لوحة التحكم' },
  { href: '/courses', icon: '📚', label: 'الدورات' },
  { href: '/mentors', icon: '👨‍🏫', label: 'المرشدون' },
  { href: '/community', icon: '💬', label: 'المجتمع' },
  { href: '/profile', icon: '👤', label: 'الملف الشخصي' },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-64 bg-white border-l border-cream-dark min-h-screen flex flex-col" dir="rtl">
      <div className="p-4 border-b border-cream-dark">
        <Link href="/" className="text-xl font-bold text-primary">شكّل</Link>
      </div>
      <nav className="flex-1 p-4 flex flex-col gap-1">
        {LINKS.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={clsx(
              'flex items-center gap-3 px-4 py-3 rounded-[10px] text-sm font-medium transition-all',
              pathname === link.href || pathname.startsWith(link.href + '/')
                ? 'bg-primary text-white'
                : 'text-ink-light hover:bg-cream hover:text-primary'
            )}
          >
            <span>{link.icon}</span>
            <span>{link.label}</span>
          </Link>
        ))}
      </nav>
      <div className="p-4 border-t border-cream-dark">
        <Link
          href="/login"
          className="flex items-center gap-3 px-4 py-3 rounded-[10px] text-sm font-medium text-ink-muted hover:text-primary hover:bg-cream transition-all"
        >
          <span>🚪</span>
          <span>تسجيل الخروج</span>
        </Link>
      </div>
    </aside>
  )
}
