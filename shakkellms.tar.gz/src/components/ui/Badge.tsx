import { clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

type BadgeVariant = 'primary' | 'accent' | 'success' | 'warning' | 'error' | 'neutral'

interface BadgeProps {
  variant?: BadgeVariant
  size?: 'sm' | 'md'
  icon?: string
  children: React.ReactNode
  className?: string
}

const variants: Record<BadgeVariant, string> = {
  primary: 'bg-primary/10 text-primary',
  accent: 'bg-accent/20 text-ink',
  success: 'bg-green-100 text-green-800',
  warning: 'bg-yellow-100 text-yellow-800',
  error: 'bg-red-100 text-red-700',
  neutral: 'bg-cream-dark text-ink-muted',
}

export default function Badge({ variant = 'primary', size = 'md', icon, children, className }: BadgeProps) {
  return (
    <span
      className={twMerge(
        clsx(
          'inline-flex items-center gap-1 rounded-full font-medium',
          size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-sm',
          variants[variant],
          className
        )
      )}
    >
      {icon && <span>{icon}</span>}
      {children}
    </span>
  )
}
