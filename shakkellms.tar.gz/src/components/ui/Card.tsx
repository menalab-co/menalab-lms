import { clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'
import React from 'react'

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  hover?: boolean
  padding?: 'none' | 'sm' | 'md' | 'lg'
  children: React.ReactNode
}

const paddingMap = {
  none: '',
  sm: 'p-3',
  md: 'p-5',
  lg: 'p-7',
}

export default function Card({ hover = false, padding = 'md', className, children, ...props }: CardProps) {
  return (
    <div
      {...props}
      className={twMerge(
        clsx(
          'bg-white rounded-lg border border-cream-dark',
          paddingMap[padding],
          hover && 'hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 cursor-pointer',
          className
        )
      )}
    >
      {children}
    </div>
  )
}
