'use client'

interface Tab {
  id: string
  label: string
  icon?: string
}

interface TabNavProps {
  tabs: Tab[]
  activeTab: string
  onChange: (id: string) => void
  className?: string
}

export default function TabNav({ tabs, activeTab, onChange, className = '' }: TabNavProps) {
  return (
    <div className={`flex gap-1 bg-cream-dark rounded-xl p-1 ${className}`} dir="rtl">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all duration-200 ${
            activeTab === tab.id
              ? 'bg-white text-primary shadow-sm'
              : 'text-ink-muted hover:text-ink hover:bg-white/50'
          }`}
        >
          {tab.icon && <span>{tab.icon}</span>}
          {tab.label}
        </button>
      ))}
    </div>
  )
}
