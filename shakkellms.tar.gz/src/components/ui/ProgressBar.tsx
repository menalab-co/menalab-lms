interface ProgressBarProps {
  value: number
  max?: number
  color?: string
  height?: 'sm' | 'md' | 'lg'
  showLabel?: boolean
  label?: string
  className?: string
}

const heights = { sm: 'h-1.5', md: 'h-2.5', lg: 'h-4' }

export default function ProgressBar({
  value,
  max = 100,
  color = 'bg-primary',
  height = 'md',
  showLabel = false,
  label,
  className = '',
}: ProgressBarProps) {
  const percentage = Math.min(100, Math.round((value / max) * 100))

  return (
    <div className={className}>
      {(showLabel || label) && (
        <div className="flex justify-between items-center mb-1 text-sm text-ink-muted">
          <span>{label || 'التقدم'}</span>
          <span>{percentage}%</span>
        </div>
      )}
      <div className={`w-full bg-cream-dark rounded-full overflow-hidden ${heights[height]}`}>
        <div
          className={`${color} ${heights[height]} rounded-full transition-all duration-500`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  )
}
