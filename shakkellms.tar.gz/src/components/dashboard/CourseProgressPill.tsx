import Link from 'next/link'
import type { Course } from '@/lib/types'

interface CourseProgressPillProps {
  course: Course
  progress: number
}

export default function CourseProgressPill({ course, progress }: CourseProgressPillProps) {
  return (
    <Link href={`/courses/${course.id}`}>
      <div className="flex items-center gap-4 p-4 bg-white border border-cream-dark rounded-xl hover:shadow-md transition-shadow">
        <div className="text-3xl">{course.category === 'تصميم' ? '🧠' : course.category === 'تصنيع' ? '⚙️' : '💻'}</div>
        <div className="flex-1 min-w-0">
          <h4 className="font-semibold text-ink text-sm mb-1 truncate">{course.title_ar}</h4>
          <div className="w-full bg-cream-dark rounded-full h-1.5">
            <div
              className="bg-primary h-1.5 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-xs text-ink-muted mt-1">{progress}% مكتمل</p>
        </div>
      </div>
    </Link>
  )
}
