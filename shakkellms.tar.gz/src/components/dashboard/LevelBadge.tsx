import { getLevelFromXP } from '@/lib/xp'

interface LevelBadgeProps {
  xp: number
  size?: 'sm' | 'md' | 'lg'
}

const sizes = {
  sm: 'text-lg px-2 py-1',
  md: 'text-2xl px-3 py-1.5',
  lg: 'text-3xl px-4 py-2',
}

export default function LevelBadge({ xp, size = 'md' }: LevelBadgeProps) {
  const level = getLevelFromXP(xp)
  return (
    <div className={`inline-flex items-center gap-2 bg-accent/20 rounded-full ${sizes[size]}`}>
      <span>{level.badge}</span>
      <div>
        <span className="text-xs text-ink-muted block leading-none">المستوى {level.level}</span>
        <span className="font-bold text-ink text-sm leading-none">{level.name_ar}</span>
      </div>
    </div>
  )
}
