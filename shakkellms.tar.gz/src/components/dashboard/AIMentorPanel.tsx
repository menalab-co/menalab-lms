'use client'

import { useState } from 'react'
import Button from '../ui/Button'

interface Message {
  role: 'user' | 'assistant'
  content: string
}

interface AIMentorPanelProps {
  credits: number
  projectId?: string
  hint?: string
}

export default function AIMentorPanel({ credits, projectId, hint }: AIMentorPanelProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: hint || 'مرحباً! أنا مرشد، مساعدك الذكي. كيف يمكنني مساعدتك اليوم؟ 😊',
    },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [currentCredits, setCurrentCredits] = useState(credits)

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault()
    if (!input.trim() || loading) return

    const userMessage = input.trim()
    setInput('')
    setMessages((prev) => [...prev, { role: 'user', content: userMessage }])
    setLoading(true)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ role: 'user', content: userMessage }],
          projectId,
        }),
      })

      const data = await res.json()

      if (data.message) {
        setMessages((prev) => [...prev, { role: 'assistant', content: data.message }])
        if (data.usedCredits) {
          setCurrentCredits((prev) => Math.max(0, prev - 1))
        }
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'عذراً، حدث خطأ. يرجى المحاولة مرة أخرى.' },
      ])
    } finally {
      setLoading(false)
    }
  }

  const recentMessages = messages.slice(-5)

  return (
    <div className="bg-white border border-cream-dark rounded-xl overflow-hidden" dir="rtl">
      <div className="bg-primary p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-accent rounded-full flex items-center justify-center font-bold text-ink">م</div>
          <div>
            <p className="font-bold text-white text-sm">مرشد</p>
            <p className="text-white/70 text-xs">مساعدك الذكي</p>
          </div>
        </div>
        <div className="bg-white/20 text-white text-xs px-3 py-1.5 rounded-full">
          {currentCredits} رصيد متبقي
        </div>
      </div>

      <div className="h-56 overflow-y-auto p-4 flex flex-col gap-3">
        {recentMessages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}>
            <div
              className={`max-w-[85%] rounded-xl px-4 py-2.5 text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-cream text-ink rounded-tr-none'
                  : 'bg-primary text-white rounded-tl-none'
              }`}
            >
              {msg.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-end">
            <div className="bg-primary/10 rounded-xl px-4 py-2.5">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-primary/40 rounded-full animate-bounce" />
                <span className="w-2 h-2 bg-primary/40 rounded-full animate-bounce delay-100" />
                <span className="w-2 h-2 bg-primary/40 rounded-full animate-bounce delay-200" />
              </div>
            </div>
          </div>
        )}
      </div>

      <form onSubmit={sendMessage} className="border-t border-cream-dark p-3 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="اسأل مرشد..."
          disabled={loading || currentCredits === 0}
          className="flex-1 bg-cream border border-cream-dark rounded-[10px] px-3 py-2 text-sm focus:outline-none focus:border-primary transition-colors"
        />
        <Button type="submit" size="sm" loading={loading} disabled={!input.trim() || currentCredits === 0}>
          إرسال
        </Button>
      </form>
      {currentCredits === 0 && (
        <p className="text-center text-xs text-red-500 pb-2">نفد رصيدك. أكمل دورة للحصول على رصيد إضافي.</p>
      )}
    </div>
  )
}
