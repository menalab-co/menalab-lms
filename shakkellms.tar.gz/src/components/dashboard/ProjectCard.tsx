import Link from 'next/link'
import type { Project } from '@/lib/types'
import { STAGE_NAMES_AR, STAGE_ICONS, STAGE_ORDER } from '@/lib/types'
import Card from '../ui/Card'
import Badge from '../ui/Badge'

interface ProjectCardProps {
  project: Project
}

export default function ProjectCard({ project }: ProjectCardProps) {
  const stageIndex = STAGE_ORDER.indexOf(project.current_stage as keyof typeof STAGE_NAMES_AR)
  const progress = Math.round(((stageIndex + 1) / STAGE_ORDER.length) * 100)

  return (
    <Link href={`/portal/${project.id}`}>
      <Card hover className="h-full">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="font-bold text-ink text-lg mb-1">{project.title}</h3>
            <p className="text-ink-muted text-sm">{project.domain}</p>
          </div>
          <Badge variant={project.status === 'active' ? 'success' : 'neutral'} size="sm">
            {project.status === 'active' ? 'نشط' : project.status === 'completed' ? 'مكتمل' : 'مؤرشف'}
          </Badge>
        </div>

        <div className="mb-4">
          <div className="flex items-center gap-2 text-sm text-ink-muted mb-2">
            <span>{STAGE_ICONS[project.current_stage as keyof typeof STAGE_ICONS]}</span>
            <span>المرحلة الحالية: {STAGE_NAMES_AR[project.current_stage as keyof typeof STAGE_NAMES_AR]}</span>
          </div>
          <div className="w-full bg-cream-dark rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-ink-muted mt-1">
            <span>التقدم</span>
            <span>{progress}%</span>
          </div>
        </div>

        <div className="flex gap-1 flex-wrap">
          {STAGE_ORDER.map((stage, i) => (
            <div
              key={stage}
              className={`text-sm px-2 py-0.5 rounded-full ${
                i <= stageIndex ? 'bg-primary text-white' : 'bg-cream-dark text-ink-muted'
              }`}
              title={STAGE_NAMES_AR[stage]}
            >
              {STAGE_ICONS[stage]}
            </div>
          ))}
        </div>
      </Card>
    </Link>
  )
}
