import Link from 'next/link'

export default function PathSelector() {
  return (
    <section className="py-20 bg-cream" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-ink mb-4">من أين تبدأ؟</h2>
          <p className="text-ink-muted text-lg">اختر المسار الذي يناسبك</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Path 1 */}
          <Link href="/onboarding/idea" className="group">
            <div className="bg-white border-2 border-cream-dark group-hover:border-primary rounded-xl p-8 text-center transition-all duration-300 group-hover:shadow-xl group-hover:-translate-y-1 h-full flex flex-col items-center">
              <div className="text-6xl mb-6">💡</div>
              <h3 className="text-2xl font-bold text-ink mb-3">عندي فكرة أو مشكلة</h3>
              <p className="text-ink-muted leading-relaxed mb-6 flex-1">
                لديك فكرة مشروع أو مشكلة تريد حلها؟ سنأخذك خلال منهجية التفكير التصميمي من التعاطف حتى بناء النموذج الحقيقي.
              </p>
              <div className="flex flex-wrap gap-2 justify-center mb-6">
                {['التعاطف', 'تحديد المشكلة', 'الأفكار', 'النموذج', 'الاختبار'].map((s) => (
                  <span key={s} className="bg-primary/10 text-primary text-xs px-3 py-1 rounded-full">{s}</span>
                ))}
              </div>
              <div className="bg-primary text-white px-8 py-3 rounded-[10px] font-bold text-lg w-full group-hover:bg-primary-dark transition-colors">
                ابدأ رحلتي ←
              </div>
            </div>
          </Link>

          {/* Path 2 */}
          <Link href="/courses" className="group">
            <div className="bg-white border-2 border-cream-dark group-hover:border-accent rounded-xl p-8 text-center transition-all duration-300 group-hover:shadow-xl group-hover:-translate-y-1 h-full flex flex-col items-center">
              <div className="text-6xl mb-6">📚</div>
              <h3 className="text-2xl font-bold text-ink mb-3">أريد التعلم عبر الدورات</h3>
              <p className="text-ink-muted leading-relaxed mb-6 flex-1">
                تعلّم مهارات التصميم والتصنيع من خلال دورات متخصصة في CAD والطباعة ثلاثية الأبعاد والليزر والإلكترونيات.
              </p>
              <div className="flex flex-wrap gap-2 justify-center mb-6">
                {['CAD', 'طباعة 3D', 'ليزر', 'Arduino', 'UX/UI'].map((s) => (
                  <span key={s} className="bg-accent/20 text-ink text-xs px-3 py-1 rounded-full">{s}</span>
                ))}
              </div>
              <div className="bg-accent text-ink px-8 py-3 rounded-[10px] font-bold text-lg w-full group-hover:bg-accent-dark transition-colors">
                استعرض الدورات ←
              </div>
            </div>
          </Link>
        </div>
      </div>
    </section>
  )
}
