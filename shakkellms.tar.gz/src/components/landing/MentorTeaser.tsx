import Link from 'next/link'

const MENTORS = [
  { name: 'أ. سارة المطيري', title: 'خبيرة تفكير تصميمي', initials: 'سم', color: 'bg-primary' },
  { name: 'م. خالد العتيبي', title: 'مهندس تصنيع', initials: 'خع', color: 'bg-accent' },
  { name: 'د. ليلى حسن', title: 'مصممة UX', initials: 'له', color: 'bg-purple-500' },
  { name: 'م. عمر الشمري', title: 'خبير طباعة 3D', initials: 'عش', color: 'bg-orange-500' },
]

export default function MentorTeaser() {
  return (
    <section className="py-20 bg-white" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-ink mb-4">تعلّم من خبراء حقيقيين</h2>
            <p className="text-ink-muted text-lg leading-relaxed mb-6">
              مرشدونا متخصصون في التفكير التصميمي والتصنيع والتصميم. يمكنك إرسال أسئلة محددة أو حجز جلسات خاصة.
            </p>
            <ul className="space-y-3 mb-8 text-ink-light">
              <li className="flex items-center gap-3"><span className="text-primary text-xl">✓</span> إجابة خلال 24 ساعة</li>
              <li className="flex items-center gap-3"><span className="text-primary text-xl">✓</span> مراجعة مشروعك وتقديم ملاحظات</li>
              <li className="flex items-center gap-3"><span className="text-primary text-xl">✓</span> جلسات فيديو مباشرة</li>
            </ul>
            <Link
              href="/mentors"
              className="bg-primary text-white px-8 py-3 rounded-[10px] font-bold text-lg hover:bg-primary-dark transition-colors inline-block"
            >
              تعرّف على المرشدين
            </Link>
          </div>
          <div>
            <div className="grid grid-cols-2 gap-4">
              {MENTORS.map((mentor) => (
                <div key={mentor.name} className="bg-cream p-5 rounded-xl flex flex-col items-center text-center">
                  <div className={`w-16 h-16 rounded-full ${mentor.color} text-white flex items-center justify-center text-xl font-bold mb-3`}>
                    {mentor.initials}
                  </div>
                  <h4 className="font-bold text-ink text-sm">{mentor.name}</h4>
                  <p className="text-ink-muted text-xs mt-1">{mentor.title}</p>
                  <div className="flex gap-0.5 mt-2">
                    {[1,2,3,4,5].map(i => <span key={i} className="text-accent text-xs">★</span>)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
