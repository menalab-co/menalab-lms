import Link from 'next/link'
import Card from '../ui/Card'
import Badge from '../ui/Badge'

const FEATURED = [
  {
    icon: '🧠',
    title: 'التفكير التصميمي',
    level: 'مبتدئ',
    duration: '4 ساعات',
    slug: 'design-thinking',
    free: true,
  },
  {
    icon: '⚙️',
    title: 'تصميم CAD بـ Fusion 360',
    level: 'متوسط',
    duration: '8 ساعات',
    slug: 'cad-fusion360',
    free: false,
    price: '199 ريال',
  },
  {
    icon: '🖨️',
    title: 'الطباعة ثلاثية الأبعاد',
    level: 'مبتدئ',
    duration: '3 ساعات',
    slug: '3d-printing',
    free: true,
  },
  {
    icon: '🔆',
    title: 'القطع بالليزر',
    level: 'مبتدئ',
    duration: '2.5 ساعة',
    slug: 'laser-cutting',
    free: false,
    price: '99 ريال',
  },
]

export default function FeaturedCourses() {
  return (
    <section className="py-20 bg-cream" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="text-4xl font-bold text-ink mb-2">الدورات المميزة</h2>
            <p className="text-ink-muted text-lg">تعلّم من الأساسيات حتى الاحتراف</p>
          </div>
          <Link href="/courses" className="text-primary font-semibold hover:underline hidden md:block">
            عرض جميع الدورات ←
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {FEATURED.map((course) => (
            <Link key={course.slug} href={`/courses/${course.slug}`}>
              <Card hover className="h-full flex flex-col">
                <div className="text-4xl mb-4">{course.icon}</div>
                <h3 className="font-bold text-ink text-lg mb-2 flex-1">{course.title}</h3>
                <div className="flex items-center gap-2 flex-wrap mt-auto pt-3 border-t border-cream-dark">
                  <Badge variant="neutral" size="sm">{course.level}</Badge>
                  <Badge variant="neutral" size="sm">⏱ {course.duration}</Badge>
                  {course.free ? (
                    <Badge variant="success" size="sm">مجاني</Badge>
                  ) : (
                    <span className="text-primary font-bold text-sm mr-auto">{course.price}</span>
                  )}
                </div>
              </Card>
            </Link>
          ))}
        </div>
        <div className="text-center mt-8 md:hidden">
          <Link href="/courses" className="text-primary font-semibold hover:underline">عرض جميع الدورات ←</Link>
        </div>
      </div>
    </section>
  )
}
