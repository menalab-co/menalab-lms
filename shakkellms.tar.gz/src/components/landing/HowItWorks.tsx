export default function HowItWorks() {
  const steps = [
    {
      number: '١',
      icon: '🧠',
      title: 'فكّر',
      subtitle: 'التعاطف وتحديد المشكلة',
      description: 'افهم مستخدمك عمقاً، وحدد المشكلة الحقيقية من خلال البحث الميداني والمقابلات.',
    },
    {
      number: '٢',
      icon: '✏️',
      title: 'صمّم',
      subtitle: 'توليد الأفكار والنمذجة',
      description: 'ولّد مئات الأفكار بدون حكم مسبق، ثم حوّل أفضلها إلى نموذج ملموس سريع.',
    },
    {
      number: '٣',
      icon: '🛠️',
      title: 'ابنِ',
      subtitle: 'الاختبار والتطوير',
      description: 'اختبر نموذجك مع مستخدمين حقيقيين، تعلّم من ردود أفعالهم، وطوّر باستمرار.',
    },
  ]

  return (
    <section className="py-20 bg-white" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-ink mb-4">كيف يعمل شكّل؟</h2>
          <p className="text-ink-muted text-lg">منهجية بسيطة وواضحة في 3 خطوات كبرى</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {/* Connector line (desktop) */}
          <div className="hidden md:block absolute top-16 right-1/6 left-1/6 h-0.5 bg-gradient-to-l from-primary via-accent to-primary opacity-30" />

          {steps.map((step, index) => (
            <div key={index} className="flex flex-col items-center text-center">
              <div className="relative mb-6">
                <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center text-3xl border-4 border-primary/20">
                  {step.icon}
                </div>
                <div className="absolute -top-2 -right-2 w-7 h-7 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold">
                  {step.number}
                </div>
              </div>
              <h3 className="text-2xl font-bold text-primary mb-1">{step.title}</h3>
              <p className="text-accent font-semibold text-sm mb-3">{step.subtitle}</p>
              <p className="text-ink-muted leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
