import Link from 'next/link'

export default function HeroSection() {
  return (
    <section className="relative bg-gradient-to-br from-primary-dark via-primary to-primary-light text-white overflow-hidden" dir="rtl">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 right-10 w-64 h-64 rounded-full bg-accent blur-3xl" />
        <div className="absolute bottom-10 left-10 w-48 h-48 rounded-full bg-white blur-3xl" />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 bg-white/20 text-white px-4 py-1.5 rounded-full text-sm font-medium mb-6">
              <span>🚀</span>
              <span>منصة التفكير التصميمي والتصنيع العربية الأولى</span>
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold leading-tight mb-6">
              شكّل
              <span className="block text-accent mt-1">مستقبلك</span>
            </h1>
            <p className="text-xl text-white/80 leading-relaxed mb-8 max-w-lg">
              تعلّم منهجية التفكير التصميمي، وبناء النماذج في مختبرات التصنيع. من الفكرة إلى الحل في 6 مراحل متكاملة.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="/onboarding/idea"
                className="bg-accent text-ink px-8 py-4 rounded-[10px] font-bold text-lg hover:bg-accent-dark transition-colors text-center shadow-lg"
              >
                💡 عندي فكرة — ابدأ
              </Link>
              <Link
                href="/courses"
                className="bg-white/20 text-white px-8 py-4 rounded-[10px] font-bold text-lg hover:bg-white/30 transition-colors text-center border border-white/30"
              >
                📚 استعرض الدورات
              </Link>
            </div>
            <div className="flex items-center gap-6 mt-8 text-white/70 text-sm">
              <span>✅ مجاني للبدء</span>
              <span>✅ بالعربية بالكامل</span>
              <span>✅ مرشد ذكاء اصطناعي</span>
            </div>
          </div>
          <div className="hidden lg:block">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
              <div className="aspect-video bg-white/5 rounded-lg flex items-center justify-center">
                <div className="text-center text-white/60">
                  <div className="text-5xl mb-3">▶️</div>
                  <p className="text-sm">فيديو تعريفي عن المنصة</p>
                  <p className="text-xs mt-1">3 دقائق</p>
                </div>
              </div>
              <div className="flex items-center gap-3 mt-3 p-3 bg-white/10 rounded-lg">
                <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-ink text-sm font-bold">م</div>
                <div className="text-sm">
                  <p className="font-medium">مرشد</p>
                  <p className="text-white/60 text-xs">مساعدك الذكي في كل خطوة</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
