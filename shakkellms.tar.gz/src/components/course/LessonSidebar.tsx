interface Lesson {
  id: string
  title_ar: string
  duration_minutes: number
  order_index: number
}

interface LessonSidebarProps {
  lessons: Lesson[]
  currentLessonId: string
  completedIds: Set<string>
}

export default function LessonSidebar({ lessons, currentLessonId, completedIds }: LessonSidebarProps) {
  return (
    <div className="bg-white border border-cream-dark rounded-xl overflow-hidden" dir="rtl">
      <div className="p-4 border-b border-cream-dark">
        <h3 className="font-bold text-ink text-sm">محتوى الدورة</h3>
      </div>
      <div className="max-h-96 overflow-y-auto">
        {lessons.sort((a, b) => a.order_index - b.order_index).map((lesson) => {
          const isActive = lesson.id === currentLessonId
          const isDone = completedIds.has(lesson.id)
          return (
            <div
              key={lesson.id}
              className={`flex items-center gap-3 p-3 border-b border-cream-dark text-sm ${
                isActive ? 'bg-primary/10' : 'hover:bg-cream'
              }`}
            >
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs flex-shrink-0 ${
                isDone ? 'bg-green-500 text-white' :
                isActive ? 'bg-primary text-white' :
                'bg-cream-dark text-ink-muted'
              }`}>
                {isDone ? '✓' : lesson.order_index + 1}
              </div>
              <div className="flex-1 min-w-0">
                <p className={`font-medium truncate ${isActive ? 'text-primary' : 'text-ink'}`}>{lesson.title_ar}</p>
                <p className="text-xs text-ink-muted">{lesson.duration_minutes} دقيقة</p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
