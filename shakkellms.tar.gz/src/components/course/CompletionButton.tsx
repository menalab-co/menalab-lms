'use client'

import { useState } from 'react'
import Button from '../ui/Button'
import { createClient } from '@/lib/supabase/client'

interface CompletionButtonProps {
  lessonId: string
  courseId: string
  nextLessonId?: string
  completed: boolean
  onComplete?: () => void
}

export default function CompletionButton({ lessonId, courseId, nextLessonId, completed, onComplete }: CompletionButtonProps) {
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(completed)

  async function handleComplete() {
    if (done) return
    setLoading(true)
    const supabase = createClient()
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) return

    await supabase.from('lesson_progress').upsert({
      user_id: session.user.id,
      lesson_id: lessonId,
      completed: true,
      completed_at: new Date().toISOString(),
    })

    setDone(true)
    setLoading(false)
    onComplete?.()
  }

  if (done) {
    return (
      <div className="flex items-center gap-3">
        <div className="bg-green-50 border border-green-200 text-green-700 rounded-[10px] px-4 py-2.5 text-sm font-medium">
          ✅ تم إتمام هذا الدرس
        </div>
        {nextLessonId && (
          <Button size="sm" onClick={() => window.location.href = `/course/${courseId}/${nextLessonId}`}>
            الدرس التالي ←
          </Button>
        )}
      </div>
    )
  }

  return (
    <Button loading={loading} onClick={handleComplete} size="lg">
      إتمام الدرس والمتابعة ✓
    </Button>
  )
}
