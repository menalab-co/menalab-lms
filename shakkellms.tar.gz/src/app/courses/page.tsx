'use client'

import { useState } from 'react'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import Card from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import Link from 'next/link'

const COURSES = [
  {
    id: 'design-thinking',
    icon: '🧠',
    title_ar: 'التفكير التصميمي',
    category: 'تصميم',
    level: 'مبتدئ',
    duration: '4 ساعات',
    price: 0,
    is_free: true,
    instructor: 'أ. سارة المطيري',
    description: 'تعلم منهجية التفكير التصميمي من الصفر حتى الاحتراف',
    ai_credits: 5,
  },
  {
    id: 'cad-fusion360',
    icon: '⚙️',
    title_ar: 'تصميم CAD بـ Fusion 360',
    category: 'تصنيع',
    level: 'متوسط',
    duration: '8 ساعات',
    price: 199,
    is_free: false,
    instructor: 'م. خالد العتيبي',
    description: 'احترف التصميم ثلاثي الأبعاد باستخدام Fusion 360',
    ai_credits: 10,
  },
  {
    id: '3d-printing',
    icon: '🖨️',
    title_ar: 'الطباعة ثلاثية الأبعاد',
    category: 'تصنيع',
    level: 'مبتدئ',
    duration: '3 ساعات',
    price: 0,
    is_free: true,
    instructor: 'م. عمر الشمري',
    description: 'من الفكرة إلى النموذج المطبوع في 6 دروس',
    ai_credits: 3,
  },
  {
    id: 'laser-cutting',
    icon: '🔆',
    title_ar: 'القطع بالليزر',
    category: 'تصنيع',
    level: 'مبتدئ',
    duration: '2.5 ساعة',
    price: 99,
    is_free: false,
    instructor: 'م. خالد العتيبي',
    description: 'تعلم تشغيل آلة الليزر بأمان واحترافية',
    ai_credits: 5,
  },
  {
    id: 'arduino-electronics',
    icon: '🔌',
    title_ar: 'الإلكترونيات وArduino',
    category: 'تقنية',
    level: 'مبتدئ',
    duration: '5 ساعات',
    price: 0,
    is_free: true,
    instructor: 'م. أحمد الدوسري',
    description: 'مقدمة في الإلكترونيات والبرمجة مع Arduino',
    ai_credits: 5,
  },
  {
    id: 'ux-ui-design',
    icon: '🎨',
    title_ar: 'تصميم UX/UI',
    category: 'تصميم',
    level: 'متوسط',
    duration: '7 ساعات',
    price: 249,
    is_free: false,
    instructor: 'د. ليلى حسن',
    description: 'صمم تجارب مستخدم مذهلة من البحث حتى التسليم',
    ai_credits: 8,
  },
  {
    id: 'cnc-machining',
    icon: '🏭',
    title_ar: 'التصنيع بالـ CNC',
    category: 'تصنيع',
    level: 'متقدم',
    duration: '6 ساعات',
    price: 349,
    is_free: false,
    instructor: 'م. فهد الزهراني',
    description: 'تعلم برمجة وتشغيل ماكينات CNC',
    ai_credits: 10,
  },
]

const CATEGORIES = ['الكل', 'تصميم', 'تصنيع', 'تقنية']

export default function CoursesPage() {
  const [activeCategory, setActiveCategory] = useState('الكل')
  const [search, setSearch] = useState('')

  const filtered = COURSES.filter(c => {
    const matchCat = activeCategory === 'الكل' || c.category === activeCategory
    const matchSearch = !search || c.title_ar.includes(search) || c.description.includes(search)
    return matchCat && matchSearch
  })

  return (
    <div className="min-h-screen bg-cream" dir="rtl">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-10">
          <h1 className="text-4xl font-bold text-ink mb-2">الدورات</h1>
          <p className="text-ink-muted text-lg">تعلّم المهارات التي تحتاجها لتصميم وبناء حلول حقيقية</p>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="flex gap-2">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-[10px] text-sm font-medium transition-all ${
                  activeCategory === cat
                    ? 'bg-primary text-white'
                    : 'bg-white border border-cream-dark text-ink-light hover:border-primary hover:text-primary'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="ابحث عن دورة..."
            className="flex-1 bg-white border border-cream-dark rounded-[10px] px-4 py-2 text-sm focus:outline-none focus:border-primary"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map(course => (
            <Link key={course.id} href={`/courses/${course.id}`}>
              <Card hover className="h-full flex flex-col">
                <div className="flex items-start justify-between mb-3">
                  <div className="text-4xl">{course.icon}</div>
                  {course.is_free
                    ? <Badge variant="success" size="sm">مجاني</Badge>
                    : <span className="font-bold text-primary text-sm">{course.price} ريال</span>
                  }
                </div>
                <h3 className="font-bold text-ink text-lg mb-1">{course.title_ar}</h3>
                <p className="text-ink-muted text-sm mb-4 flex-1">{course.description}</p>
                <div className="flex flex-wrap gap-2 pt-3 border-t border-cream-dark">
                  <Badge variant="neutral" size="sm">{course.category}</Badge>
                  <Badge variant="neutral" size="sm">{course.level}</Badge>
                  <Badge variant="neutral" size="sm">⏱ {course.duration}</Badge>
                </div>
                <p className="text-xs text-ink-muted mt-3">المدرب: {course.instructor}</p>
                {course.ai_credits > 0 && (
                  <p className="text-xs text-primary mt-1">+{course.ai_credits} رصيد مرشد</p>
                )}
              </Card>
            </Link>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
