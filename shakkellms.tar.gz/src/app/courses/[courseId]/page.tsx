import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import Link from 'next/link'

const COURSE_DATA: Record<string, {
  icon: string; title_ar: string; category: string; level: string;
  duration: string; price: number; is_free: boolean; instructor: string;
  description: string; ai_credits: number;
  whatYouLearn: string[]; prerequisites: string[];
  lessons: { title_ar: string; duration: string; type: string }[]
}> = {
  'design-thinking': {
    icon: '🧠', title_ar: 'التفكير التصميمي', category: 'تصميم', level: 'مبتدئ',
    duration: '4 ساعات', price: 0, is_free: true, instructor: 'أ. سارة المطيري',
    description: 'تعلم منهجية التفكير التصميمي من الصفر حتى الاحتراف', ai_credits: 5,
    whatYouLearn: [
      'فهم مراحل التفكير التصميمي الخمس',
      'إجراء مقابلات مستخدمين فعّالة',
      'بناء خريطة تعاطف شاملة',
      'صياغة عبارات POV و HMW',
      'تقنيات العصف الذهني المتقدمة',
      'بناء نماذج أولية سريعة',
    ],
    prerequisites: ['لا يوجد متطلبات سابقة', 'فضول وشغف بحل المشكلات'],
    lessons: [
      { title_ar: 'مقدمة في التفكير التصميمي', duration: '25 دقيقة', type: 'video' },
      { title_ar: 'مرحلة التعاطف - الأساس', duration: '40 دقيقة', type: 'video' },
      { title_ar: 'تقنيات المقابلة والملاحظة', duration: '35 دقيقة', type: 'lab' },
      { title_ar: 'تحديد المشكلة و POV', duration: '30 دقيقة', type: 'video' },
      { title_ar: 'توليد الأفكار و SCAMPER', duration: '40 دقيقة', type: 'exercise' },
      { title_ar: 'النمذجة السريعة', duration: '30 دقيقة', type: 'lab' },
    ],
  },
  'cad-fusion360': {
    icon: '⚙️', title_ar: 'تصميم CAD بـ Fusion 360', category: 'تصنيع', level: 'متوسط',
    duration: '8 ساعات', price: 199, is_free: false, instructor: 'م. خالد العتيبي',
    description: 'احترف التصميم ثلاثي الأبعاد باستخدام Fusion 360', ai_credits: 10,
    whatYouLearn: ['واجهة Fusion 360', 'رسم Sketch ثنائي الأبعاد', 'Extrude وRevolve', 'Assembly المجسمات', 'تصدير للطباعة ثلاثية الأبعاد'],
    prerequisites: ['معرفة أساسية بالكمبيوتر', 'تثبيت Fusion 360 مجاناً'],
    lessons: [
      { title_ar: 'تنزيل وإعداد Fusion 360', duration: '20 دقيقة', type: 'text' },
      { title_ar: 'واجهة البرنامج والتنقل', duration: '35 دقيقة', type: 'video' },
      { title_ar: 'رسم أشكال ثنائية الأبعاد', duration: '45 دقيقة', type: 'video' },
      { title_ar: 'تحويل الرسمة لجسم ثلاثي', duration: '50 دقيقة', type: 'video' },
      { title_ar: 'مشروع عملي: علبة بسيطة', duration: '60 دقيقة', type: 'lab' },
    ],
  },
}

const DEFAULT_COURSE = {
  icon: '📚', title_ar: 'الدورة', category: 'عام', level: 'مبتدئ',
  duration: '3 ساعات', price: 0, is_free: true, instructor: 'المدرب', description: '', ai_credits: 3,
  whatYouLearn: ['مهارة 1', 'مهارة 2', 'مهارة 3'],
  prerequisites: ['لا يوجد متطلبات'],
  lessons: [
    { title_ar: 'الدرس الأول', duration: '30 دقيقة', type: 'video' },
    { title_ar: 'الدرس الثاني', duration: '30 دقيقة', type: 'video' },
  ],
}

const TYPE_ICON: Record<string, string> = {
  video: '🎬', text: '📄', exercise: '✏️', lab: '🔧',
}

interface Props {
  params: { courseId: string }
}

export default function CourseDetailPage({ params }: Props) {
  const course = COURSE_DATA[params.courseId] || DEFAULT_COURSE

  return (
    <div className="min-h-screen bg-cream" dir="rtl">
      <Header />
      <main>
        {/* Hero */}
        <div className="bg-gradient-to-l from-primary-dark to-primary text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
            <div className="max-w-3xl">
              <div className="flex items-center gap-3 mb-4">
                <span className="text-5xl">{course.icon}</span>
                <div>
                  <p className="text-white/70 text-sm">{course.category} • {course.level}</p>
                  <h1 className="text-3xl font-bold">{course.title_ar}</h1>
                </div>
              </div>
              <p className="text-white/80 text-lg mb-6">{course.description}</p>
              <div className="flex flex-wrap gap-4 text-sm text-white/70">
                <span>👨‍🏫 {course.instructor}</span>
                <span>⏱ {course.duration}</span>
                <span>🎓 {course.lessons.length} درس</span>
                {course.ai_credits > 0 && <span>✨ +{course.ai_credits} رصيد مرشد</span>}
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              {/* What you'll learn */}
              <div className="bg-white rounded-xl border border-cream-dark p-6">
                <h2 className="text-xl font-bold text-ink mb-4">ماذا ستتعلم؟</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {course.whatYouLearn.map((item, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-ink-light">
                      <span className="text-primary mt-0.5">✓</span>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Curriculum */}
              <div className="bg-white rounded-xl border border-cream-dark p-6">
                <h2 className="text-xl font-bold text-ink mb-4">المحتوى</h2>
                <div className="space-y-2">
                  {course.lessons.map((lesson, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-[10px] border border-cream-dark">
                      <div className="flex items-center gap-3">
                        <span>{TYPE_ICON[lesson.type] || '📄'}</span>
                        <span className="text-sm font-medium text-ink">{lesson.title_ar}</span>
                      </div>
                      <span className="text-xs text-ink-muted">{lesson.duration}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Prerequisites */}
              <div className="bg-white rounded-xl border border-cream-dark p-6">
                <h2 className="text-xl font-bold text-ink mb-4">المتطلبات</h2>
                <ul className="space-y-2">
                  {course.prerequisites.map((p, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-ink-light">
                      <span className="text-accent mt-0.5">•</span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Enroll card */}
            <div>
              <div className="bg-white rounded-xl border border-cream-dark p-6 sticky top-24">
                <div className="text-center mb-4">
                  {course.is_free ? (
                    <p className="text-3xl font-bold text-primary">مجاني</p>
                  ) : (
                    <p className="text-3xl font-bold text-primary">{course.price} ريال</p>
                  )}
                </div>
                <Link
                  href="/signup"
                  className="block w-full bg-primary text-white text-center py-3.5 rounded-[10px] font-bold hover:bg-primary-dark transition-colors mb-3"
                >
                  {course.is_free ? 'ابدأ مجاناً' : 'سجّل الآن'}
                </Link>
                <p className="text-center text-xs text-ink-muted mb-4">ضمان استرداد الأموال خلال 30 يوماً</p>
                {course.ai_credits > 0 && (
                  <div className="bg-accent/10 rounded-[10px] p-3 text-center text-sm text-ink">
                    ✨ تشمل {course.ai_credits} رصيد لمرشد الذكاء الاصطناعي
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
