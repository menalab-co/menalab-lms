import Header from '@/components/layout/Header'
import LessonSidebar from '@/components/course/LessonSidebar'
import CompletionButton from '@/components/course/CompletionButton'
import AIMentorPanel from '@/components/dashboard/AIMentorPanel'

const MOCK_LESSONS = [
  { id: 'l1', title_ar: 'مقدمة في التفكير التصميمي', duration_minutes: 25, order_index: 0, content: 'التفكير التصميمي هو منهجية مبتكرة تضع الإنسان في مركز عملية حل المشكلات...' },
  { id: 'l2', title_ar: 'مرحلة التعاطف', duration_minutes: 40, order_index: 1, content: 'التعاطف هو الخطوة الأولى والأهم في التفكير التصميمي...' },
  { id: 'l3', title_ar: 'تقنيات المقابلة', duration_minutes: 35, order_index: 2, content: 'المقابلة الجيدة تعتمد على الإنصات أكثر من الكلام...' },
]

interface Props {
  params: { courseId: string; lessonId: string }
}

export default function LessonPage({ params }: Props) {
  const lesson = MOCK_LESSONS.find(l => l.id === params.lessonId) || MOCK_LESSONS[0]
  const currentIndex = MOCK_LESSONS.findIndex(l => l.id === params.lessonId)
  const nextLesson = MOCK_LESSONS[currentIndex + 1]

  return (
    <div className="min-h-screen bg-cream" dir="rtl">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Video player */}
            <div className="bg-black rounded-xl overflow-hidden aspect-video flex items-center justify-center">
              <div className="text-center text-white/60">
                <div className="text-5xl mb-3">▶️</div>
                <p>{lesson.title_ar}</p>
              </div>
            </div>

            {/* Lesson info */}
            <div className="bg-white rounded-xl border border-cream-dark p-6">
              <h1 className="text-2xl font-bold text-ink mb-2">{lesson.title_ar}</h1>
              <p className="text-ink-muted text-sm mb-4">⏱ {lesson.duration_minutes} دقيقة</p>

              <div className="prose prose-sm max-w-none text-ink-light leading-relaxed">
                {lesson.content}
              </div>

              <div className="mt-6 pt-4 border-t border-cream-dark">
                <CompletionButton
                  lessonId={lesson.id}
                  courseId={params.courseId}
                  nextLessonId={nextLesson?.id}
                  completed={false}
                />
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <LessonSidebar
              lessons={MOCK_LESSONS}
              currentLessonId={lesson.id}
              completedIds={new Set()}
            />
            <AIMentorPanel credits={10} />
          </div>
        </div>
      </main>
    </div>
  )
}
