import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import HeroSection from '@/components/landing/HeroSection'
import PathSelector from '@/components/landing/PathSelector'
import HowItWorks from '@/components/landing/HowItWorks'
import FeaturedCourses from '@/components/landing/FeaturedCourses'
import MentorTeaser from '@/components/landing/MentorTeaser'
import Link from 'next/link'

const COMMUNITY_POSTS = [
  { title: 'كيف أكتب POV statement قوي؟', tag: 'تحديد المشكلة', votes: 24, replies: 7, solved: true },
  { title: 'نصائح لمقابلة المستخدمين الأولى', tag: 'التعاطف', votes: 18, replies: 5, solved: false },
  { title: 'ما الفرق بين النمذجة الورقية والرقمية؟', tag: 'النمذجة', votes: 31, replies: 12, solved: true },
]

export default function HomePage() {
  return (
    <div className="min-h-screen" dir="rtl">
      <Header />
      <main>
        <HeroSection />
        <PathSelector />
        <HowItWorks />
        <FeaturedCourses />
        <MentorTeaser />

        {/* Community Teaser */}
        <section className="py-20 bg-cream" dir="rtl">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-end justify-between mb-10">
              <div>
                <h2 className="text-4xl font-bold text-ink mb-2">مجتمع شكّل</h2>
                <p className="text-ink-muted">تعلّم من تجارب الآخرين وشارك خبرتك</p>
              </div>
              <Link href="/community" className="text-primary font-semibold hover:underline hidden md:block">
                انضم للمجتمع ←
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {COMMUNITY_POSTS.map((post, i) => (
                <div key={i} className="bg-white border border-cream-dark rounded-xl p-5 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <span className="bg-primary/10 text-primary text-xs px-2 py-0.5 rounded-full">{post.tag}</span>
                    {post.solved && (
                      <span className="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full">✓ محلول</span>
                    )}
                  </div>
                  <h4 className="font-semibold text-ink mb-4">{post.title}</h4>
                  <div className="flex items-center gap-4 text-ink-muted text-xs">
                    <span>👍 {post.votes}</span>
                    <span>💬 {post.replies} رد</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary text-white" dir="rtl">
          <div className="max-w-3xl mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold mb-4">جاهز لتشكيل مستقبلك؟</h2>
            <p className="text-white/80 text-xl mb-8">انضم لآلاف المبتكرين العرب على منصة شكّل</p>
            <Link
              href="/signup"
              className="bg-accent text-ink px-10 py-4 rounded-[10px] font-bold text-xl hover:bg-accent-dark transition-colors inline-block shadow-lg"
            >
              ابدأ مجاناً الآن
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
