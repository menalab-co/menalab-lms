import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'شكّل - منصة التفكير التصميمي والتصنيع',
  description: 'تعلم التفكير التصميمي وبناء النماذج في مختبرات التصنيع',
  icons: {
    icon: '/favicon.ico',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;500;600;700&family=Cairo:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-arabic bg-cream text-ink min-h-screen">
        {children}
      </body>
    </html>
  )
}
