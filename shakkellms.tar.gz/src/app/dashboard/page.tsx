import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import Sidebar from '@/components/layout/Sidebar'
import LevelBadge from '@/components/dashboard/LevelBadge'
import ProjectCard from '@/components/dashboard/ProjectCard'
import CourseProgressPill from '@/components/dashboard/CourseProgressPill'
import AIMentorPanel from '@/components/dashboard/AIMentorPanel'
import ProgressBar from '@/components/ui/ProgressBar'
import { getLevelProgress, getXPToNextLevel } from '@/lib/xp'
import { BADGE_DEFINITIONS } from '@/lib/types'

export default async function DashboardPage() {
  const supabase = createClient()
  const { data: { session } } = await supabase.auth.getSession()

  if (!session) redirect('/login')

  const [
    { data: user },
    { data: projects },
    { data: enrollments },
    { data: badges },
  ] = await Promise.all([
    supabase.from('users').select('*').eq('id', session.user.id).single(),
    supabase.from('projects').select('*').eq('user_id', session.user.id).order('created_at', { ascending: false }),
    supabase.from('enrollments').select('*, courses(*)').eq('user_id', session.user.id),
    supabase.from('badges').select('*').eq('user_id', session.user.id),
  ])

  const userData = user || {
    name: session.user.email?.split('@')[0] || 'المستخدم',
    xp: 0,
    ai_credits: 10,
    max_credits: 10,
    level: 1,
    streak: 0,
  }

  const earnedBadgeSlugs = new Set((badges || []).map((b: { badge_slug: string }) => b.badge_slug))

  return (
    <div className="flex min-h-screen bg-cream" dir="rtl">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="max-w-5xl mx-auto px-6 py-8">

          {/* Header */}
          <div className="bg-white rounded-xl p-6 mb-6 border border-cream-dark">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <p className="text-ink-muted text-sm mb-1">مرحباً بك،</p>
                <h1 className="text-3xl font-bold text-ink">{userData.name} 👋</h1>
                <div className="flex items-center gap-3 mt-2">
                  <LevelBadge xp={userData.xp} />
                  {userData.streak > 0 && (
                    <span className="text-sm text-ink-muted">🔥 {userData.streak} يوم متواصل</span>
                  )}
                </div>
              </div>
              <div className="w-full md:w-64">
                <div className="flex justify-between text-sm text-ink-muted mb-1">
                  <span>{userData.xp} نقطة XP</span>
                  <span>حتى المستوى التالي: {getXPToNextLevel(userData.xp)}</span>
                </div>
                <ProgressBar value={getLevelProgress(userData.xp)} color="bg-accent" height="md" />
                <div className="flex justify-between text-xs text-ink-muted mt-1">
                  <span>التقدم</span>
                  <span>{getLevelProgress(userData.xp)}%</span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              {/* Projects Section */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-ink">مشاريعي</h2>
                  <Link
                    href="/onboarding/idea"
                    className="bg-primary text-white px-4 py-2 rounded-[10px] text-sm font-semibold hover:bg-primary-dark transition-colors"
                  >
                    + مشروع جديد
                  </Link>
                </div>

                {!projects || projects.length === 0 ? (
                  <div className="bg-white border-2 border-dashed border-cream-dark rounded-xl p-10 text-center">
                    <div className="text-4xl mb-3">🚀</div>
                    <h3 className="font-bold text-ink text-lg mb-2">لا توجد مشاريع بعد</h3>
                    <p className="text-ink-muted text-sm mb-4">ابدأ رحلتك في التفكير التصميمي بإنشاء مشروعك الأول</p>
                    <Link
                      href="/onboarding/idea"
                      className="bg-primary text-white px-6 py-3 rounded-[10px] font-bold hover:bg-primary-dark transition-colors inline-block"
                    >
                      ابدأ مشروعاً جديداً
                    </Link>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {projects.map((project) => (
                      <ProjectCard key={project.id} project={project} />
                    ))}
                  </div>
                )}
              </div>

              {/* Courses Section */}
              {enrollments && enrollments.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-ink">دوراتي</h2>
                    <Link href="/courses" className="text-primary text-sm hover:underline">عرض الكل</Link>
                  </div>
                  <div className="space-y-3">
                    {enrollments.map((enrollment: { id: string; courses: { id: string; title_ar: string; title_en: string; category: string; slug: string } | null }) => (
                      enrollment.courses && (
                        <CourseProgressPill
                          key={enrollment.id}
                          course={enrollment.courses as Parameters<typeof CourseProgressPill>[0]['course']}
                          progress={0}
                        />
                      )
                    ))}
                  </div>
                </div>
              )}

              {/* Badges */}
              <div>
                <h2 className="text-xl font-bold text-ink mb-4">الشارات</h2>
                <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
                  {BADGE_DEFINITIONS.map((badge) => {
                    const earned = earnedBadgeSlugs.has(badge.slug)
                    return (
                      <div
                        key={badge.slug}
                        title={badge.description}
                        className={`flex flex-col items-center p-3 rounded-xl text-center ${
                          earned ? 'bg-white border border-accent/30' : 'bg-cream-dark opacity-50'
                        }`}
                      >
                        <div className="text-2xl mb-1">{badge.icon}</div>
                        <p className="text-xs font-medium text-ink leading-tight">{badge.name_ar}</p>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>

            {/* Right panel */}
            <div className="space-y-6">
              {/* AI Mentor */}
              <AIMentorPanel credits={userData.ai_credits} />

              {/* Quick Stats */}
              <div className="bg-white border border-cream-dark rounded-xl p-5">
                <h3 className="font-bold text-ink mb-4">إحصائياتي</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-ink-muted">إجمالي نقاط XP</span>
                    <span className="font-bold text-primary">{userData.xp}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-ink-muted">المشاريع</span>
                    <span className="font-bold">{projects?.length || 0}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-ink-muted">الدورات</span>
                    <span className="font-bold">{enrollments?.length || 0}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-ink-muted">الشارات</span>
                    <span className="font-bold">{badges?.length || 0}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
