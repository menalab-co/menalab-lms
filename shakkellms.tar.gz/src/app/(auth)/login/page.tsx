'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import Button from '@/components/ui/Button'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const supabase = createClient()
      const { error: authError } = await supabase.auth.signInWithPassword({ email, password })

      if (authError) {
        setError(authError.message === 'Invalid login credentials'
          ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
          : 'حدث خطأ، يرجى المحاولة مرة أخرى')
      } else {
        router.push('/dashboard')
        router.refresh()
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-cream flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="text-3xl font-bold text-primary">شكّل</Link>
          <p className="text-ink-muted mt-2">سجّل الدخول لمتابعة رحلتك</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-cream-dark p-8">
          <h1 className="text-2xl font-bold text-ink mb-6">تسجيل الدخول</h1>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 rounded-[10px] p-3 mb-4 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">البريد الإلكتروني</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="example@email.com"
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary focus:bg-white transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">كلمة المرور</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                placeholder="••••••••"
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary focus:bg-white transition-colors"
              />
            </div>

            <Button type="submit" loading={loading} className="w-full mt-2">
              تسجيل الدخول
            </Button>
          </form>

          <p className="text-center text-sm text-ink-muted mt-6">
            ليس لديك حساب؟{' '}
            <Link href="/signup" className="text-primary font-semibold hover:underline">إنشاء حساب جديد</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
