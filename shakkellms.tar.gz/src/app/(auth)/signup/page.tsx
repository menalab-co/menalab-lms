'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import Button from '@/components/ui/Button'

export default function SignupPage() {
  const router = useRouter()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')

    if (password.length < 6) {
      setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل')
      return
    }

    setLoading(true)
    try {
      const supabase = createClient()
      const { data, error: authError } = await supabase.auth.signUp({ email, password })

      if (authError) {
        setError('حدث خطأ في إنشاء الحساب. يرجى المحاولة مرة أخرى.')
        return
      }

      if (data.user) {
        // Insert user profile
        await supabase.from('users').insert({
          id: data.user.id,
          name,
          email,
          level: 1,
          xp: 0,
          ai_credits: 10,
          max_credits: 10,
          streak: 0,
        })
        router.push('/dashboard')
        router.refresh()
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-cream flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="text-3xl font-bold text-primary">شكّل</Link>
          <p className="text-ink-muted mt-2">انضم لمجتمع المبتكرين العرب</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-cream-dark p-8">
          <h1 className="text-2xl font-bold text-ink mb-6">إنشاء حساب جديد</h1>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 rounded-[10px] p-3 mb-4 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">الاسم الكامل</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                placeholder="محمد عبدالله"
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary focus:bg-white transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">البريد الإلكتروني</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="example@email.com"
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary focus:bg-white transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">كلمة المرور</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                placeholder="6 أحرف على الأقل"
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary focus:bg-white transition-colors"
              />
            </div>

            <Button type="submit" loading={loading} className="w-full mt-2">
              إنشاء الحساب
            </Button>
          </form>

          <p className="text-center text-xs text-ink-muted mt-4">
            بإنشاء حساب أنت توافق على{' '}
            <Link href="#" className="text-primary hover:underline">شروط الاستخدام</Link>
            {' '}و{' '}
            <Link href="#" className="text-primary hover:underline">سياسة الخصوصية</Link>
          </p>

          <p className="text-center text-sm text-ink-muted mt-4">
            لديك حساب؟{' '}
            <Link href="/login" className="text-primary font-semibold hover:underline">تسجيل الدخول</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
