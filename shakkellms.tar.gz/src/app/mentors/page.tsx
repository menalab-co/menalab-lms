'use client'

import { useState } from 'react'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import Modal from '@/components/ui/Modal'
import Button from '@/components/ui/Button'
import Badge from '@/components/ui/Badge'

const MENTORS = [
  {
    id: '1', name: 'أ. سارة المطيري', title: 'خبيرة تفكير تصميمي', initials: 'سم',
    color: 'bg-primary', bio: 'خبرة 8 سنوات في التفكير التصميمي مع IDEO وغوغل. درّبت أكثر من 500 طالب.',
    specialties: ['التعاطف', 'تحديد المشكلة', 'البحث النوعي'],
    rating: 4.9, session_count: 243, response_time_hours: 12, available: true,
  },
  {
    id: '2', name: 'م. خالد العتيبي', title: 'مهندس تصنيع ومبتكر', initials: 'خع',
    color: 'bg-accent', bio: 'مهندس ميكانيكي ومتخصص في Makerspace. بنى أكثر من 100 نموذج أولي.',
    specialties: ['CAD', 'طباعة 3D', 'ليزر', 'CNC'],
    rating: 4.8, session_count: 187, response_time_hours: 24, available: true,
  },
  {
    id: '3', name: 'د. ليلى حسن', title: 'مصممة UX ومستشارة', initials: 'له',
    color: 'bg-purple-500', bio: 'دكتوراه في تجربة المستخدم. عملت مع أكبر الشركات في المنطقة.',
    specialties: ['UX/UI', 'بحث المستخدم', 'نمذجة Figma'],
    rating: 4.9, session_count: 312, response_time_hours: 8, available: true,
  },
  {
    id: '4', name: 'م. عمر الشمري', title: 'خبير طباعة ثلاثية الأبعاد', initials: 'عش',
    color: 'bg-orange-500', bio: 'متخصص في الطباعة ثلاثية الأبعاد والنمذجة بالبلاستيك.',
    specialties: ['طباعة 3D', 'Fusion 360', 'مواد'],
    rating: 4.7, session_count: 142, response_time_hours: 18, available: false,
  },
  {
    id: '5', name: 'م. أحمد الدوسري', title: 'مهندس إلكترونيات', initials: 'أد',
    color: 'bg-blue-500', bio: 'مهندس إلكترونيات متخصص في Arduino وIoT والروبوتات.',
    specialties: ['Arduino', 'إلكترونيات', 'IoT', 'برمجة'],
    rating: 4.8, session_count: 198, response_time_hours: 16, available: true,
  },
  {
    id: '6', name: 'م. فاطمة النجار', title: 'مصممة صناعية', initials: 'فن',
    color: 'bg-pink-500', bio: 'مصممة صناعية متخصصة في منتجات المستهلك والتغليف.',
    specialties: ['تصميم صناعي', 'نمذجة', 'مواد', 'التفكير التصميمي'],
    rating: 4.6, session_count: 89, response_time_hours: 20, available: true,
  },
]

export default function MentorsPage() {
  const [askModal, setAskModal] = useState<typeof MENTORS[0] | null>(null)
  const [sessionModal, setSessionModal] = useState<typeof MENTORS[0] | null>(null)
  const [question, setQuestion] = useState('')
  const [sessionNote, setSessionNote] = useState('')
  const [sent, setSent] = useState(false)

  async function handleSendQuestion() {
    setSent(true)
    setTimeout(() => { setSent(false); setAskModal(null); setQuestion('') }, 2000)
  }

  return (
    <div className="min-h-screen bg-cream" dir="rtl">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-10">
          <h1 className="text-4xl font-bold text-ink mb-2">المرشدون</h1>
          <p className="text-ink-muted text-lg">تعلّم من خبراء حقيقيين في التصميم والتصنيع</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {MENTORS.map(mentor => (
            <div key={mentor.id} className="bg-white border border-cream-dark rounded-xl p-6">
              <div className="flex items-start gap-4 mb-4">
                <div className={`w-16 h-16 rounded-full ${mentor.color} text-white flex items-center justify-center text-xl font-bold flex-shrink-0`}>
                  {mentor.initials}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold text-ink">{mentor.name}</h3>
                      <p className="text-ink-muted text-sm">{mentor.title}</p>
                    </div>
                    <Badge variant={mentor.available ? 'success' : 'neutral'} size="sm">
                      {mentor.available ? 'متاح' : 'مشغول'}
                    </Badge>
                  </div>
                </div>
              </div>

              <p className="text-sm text-ink-light mb-4 leading-relaxed">{mentor.bio}</p>

              <div className="flex flex-wrap gap-1.5 mb-4">
                {mentor.specialties.map(s => (
                  <span key={s} className="bg-primary/10 text-primary text-xs px-2.5 py-1 rounded-full">{s}</span>
                ))}
              </div>

              <div className="flex items-center gap-4 text-sm text-ink-muted mb-4">
                <div className="flex gap-0.5">
                  {[1,2,3,4,5].map(i => (
                    <span key={i} className={i <= Math.floor(mentor.rating) ? 'text-accent' : 'text-cream-dark'}>★</span>
                  ))}
                  <span className="mr-1">{mentor.rating}</span>
                </div>
                <span>{mentor.session_count} جلسة</span>
                <span>⏱ {mentor.response_time_hours}س</span>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setAskModal(mentor)}
                  className="flex-1 border border-primary text-primary py-2 rounded-[10px] text-sm font-medium hover:bg-primary hover:text-white transition-colors"
                >
                  اسأل سؤالاً
                </button>
                <button
                  onClick={() => setSessionModal(mentor)}
                  disabled={!mentor.available}
                  className="flex-1 bg-primary text-white py-2 rounded-[10px] text-sm font-medium hover:bg-primary-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  احجز جلسة
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
      <Footer />

      {/* Ask Question Modal */}
      <Modal open={!!askModal} onClose={() => setAskModal(null)} title={`اسأل ${askModal?.name}`} size="md">
        <div className="p-6" dir="rtl">
          {sent ? (
            <div className="text-center py-8">
              <div className="text-4xl mb-3">✅</div>
              <p className="font-bold text-ink text-lg">تم إرسال سؤالك!</p>
              <p className="text-ink-muted text-sm mt-2">سيجيبك {askModal?.name} خلال {askModal?.response_time_hours} ساعة</p>
            </div>
          ) : (
            <>
              <p className="text-sm text-ink-muted mb-4">اكتب سؤالك بوضوح وتفصيل للحصول على إجابة دقيقة.</p>
              <textarea
                value={question}
                onChange={e => setQuestion(e.target.value)}
                rows={5}
                placeholder="سؤالك هنا..."
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary transition-colors resize-none mb-4"
              />
              <div className="flex gap-3 justify-end">
                <Button variant="outline" onClick={() => setAskModal(null)}>إلغاء</Button>
                <Button onClick={handleSendQuestion} disabled={!question.trim()}>إرسال السؤال</Button>
              </div>
            </>
          )}
        </div>
      </Modal>

      {/* Session Modal */}
      <Modal open={!!sessionModal} onClose={() => setSessionModal(null)} title={`احجز جلسة مع ${sessionModal?.name}`} size="md">
        <div className="p-6" dir="rtl">
          <p className="text-sm text-ink-muted mb-4">اكتب موضوع الجلسة وما تريد الحصول عليه منها.</p>
          <textarea
            value={sessionNote}
            onChange={e => setSessionNote(e.target.value)}
            rows={4}
            placeholder="موضوع الجلسة وأهدافك..."
            className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary transition-colors resize-none mb-4"
          />
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={() => setSessionModal(null)}>إلغاء</Button>
            <Button onClick={() => setSessionModal(null)} disabled={!sessionNote.trim()}>طلب الجلسة</Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}
