'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import Button from '@/components/ui/Button'
import { STAGE_ORDER } from '@/lib/types'

const DOMAINS = [
  { value: 'education', label: 'التعليم' },
  { value: 'health', label: 'الصحة' },
  { value: 'environment', label: 'البيئة' },
  { value: 'community', label: 'المجتمع' },
  { value: 'technology', label: 'التقنية' },
  { value: 'other', label: 'أخرى' },
]

export default function IdeaOnboardingPage() {
  const router = useRouter()
  const [idea, setIdea] = useState('')
  const [affected, setAffected] = useState('')
  const [domain, setDomain] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!idea.trim() || !affected.trim() || !domain) {
      setError('يرجى ملء جميع الحقول')
      return
    }

    setLoading(true)
    setError('')

    try {
      const supabase = createClient()
      const { data: { session } } = await supabase.auth.getSession()

      if (!session) {
        router.push('/login')
        return
      }

      // Create project
      const { data: project, error: projectError } = await supabase
        .from('projects')
        .insert({
          user_id: session.user.id,
          title: idea.slice(0, 100),
          domain: DOMAINS.find(d => d.value === domain)?.label || domain,
          current_stage: 'empathy',
          status: 'active',
        })
        .select()
        .single()

      if (projectError || !project) {
        setError('حدث خطأ في إنشاء المشروع')
        return
      }

      // Create all stage records
      const stageInserts = STAGE_ORDER.map((stage, i) => ({
        project_id: project.id,
        stage_name: stage,
        content_viewed: false,
        templates_submitted: [],
        assessment_passed: false,
        unlocked_at: i === 0 ? new Date().toISOString() : null,
      }))

      await supabase.from('project_stages').insert(stageInserts)

      router.push(`/portal/${project.id}/empathy`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-cream flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-lg">
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">💡</div>
          <h1 className="text-3xl font-bold text-ink mb-2">أخبرني عن فكرتك</h1>
          <p className="text-ink-muted">لا تقلق إذا لم تكن واضحة تماماً — سنكتشف معاً المشكلة الحقيقية</p>
        </div>

        <div className="bg-white rounded-xl border border-cream-dark p-8 shadow-sm">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 rounded-[10px] p-3 mb-4 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">
                ما هي مشكلتك أو فكرتك؟ <span className="text-red-500">*</span>
              </label>
              <textarea
                value={idea}
                onChange={(e) => setIdea(e.target.value)}
                required
                rows={4}
                placeholder="مثال: لاحظت أن الطلاب في مدرستنا لا يمارسون الرياضة بشكل كافٍ بسبب..."
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary focus:bg-white transition-colors resize-none"
              />
              <p className="text-xs text-ink-muted mt-1">{idea.length}/300 حرف</p>
            </div>

            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">
                من يتأثر بهذه المشكلة؟ <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={affected}
                onChange={(e) => setAffected(e.target.value)}
                required
                placeholder="مثال: الطلاب في المرحلة الثانوية، أهالي الحي، موظفو الشركات..."
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary focus:bg-white transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-ink mb-2">
                ما المجال؟ <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-3 gap-2">
                {DOMAINS.map((d) => (
                  <button
                    key={d.value}
                    type="button"
                    onClick={() => setDomain(d.value)}
                    className={`py-2.5 px-3 rounded-[10px] text-sm font-medium border-2 transition-all ${
                      domain === d.value
                        ? 'border-primary bg-primary text-white'
                        : 'border-cream-dark text-ink-light hover:border-primary hover:text-primary'
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            </div>

            <Button type="submit" loading={loading} size="lg" className="w-full mt-2">
              إنشاء المشروع وابدأ رحلتي 🚀
            </Button>
          </form>
        </div>

        <p className="text-center text-sm text-ink-muted mt-4">
          <Link href="/dashboard" className="text-primary hover:underline">← العودة للوحة التحكم</Link>
        </p>
      </div>
    </div>
  )
}
