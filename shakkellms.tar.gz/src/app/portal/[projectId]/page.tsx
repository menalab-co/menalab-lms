import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { STAGE_ORDER, STAGE_NAMES_AR, STAGE_ICONS } from '@/lib/types'

interface Props {
  params: { projectId: string }
}

export default async function ProjectPortalPage({ params }: Props) {
  const supabase = createClient()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) redirect('/login')

  const { data: project } = await supabase
    .from('projects')
    .select('*')
    .eq('id', params.projectId)
    .eq('user_id', session.user.id)
    .single()

  if (!project) redirect('/dashboard')

  // Redirect to current stage
  redirect(`/portal/${params.projectId}/${project.current_stage}`)
}
