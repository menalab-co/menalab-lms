'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Sidebar from '@/components/layout/Sidebar'
import StageHeader from '@/components/portal/StageHeader'
import StageChecklist from '@/components/portal/StageChecklist'
import TemplateCard from '@/components/portal/TemplateCard'
import TemplateModal from '@/components/portal/TemplateModal'
import InlineQuiz from '@/components/portal/InlineQuiz'
import AIMentorPanel from '@/components/dashboard/AIMentorPanel'
import TabNav from '@/components/ui/TabNav'
import { createClient } from '@/lib/supabase/client'
import { STAGE_ORDER, STAGE_TEMPLATES, STAGE_NAMES_AR, STAGE_ICONS } from '@/lib/types'
import type { StageKey, Template, TemplateSubmission, QuizQuestion, Project, ProjectStage } from '@/lib/types'

interface Props {
  params: { projectId: string; stage: string }
}

const STAGE_CONTENT: Record<StageKey, { intro: string; video?: string }> = {
  empathy: {
    intro: `مرحلة التعاطف هي أساس كل شيء. هنا تنزل من برجك العاجي وتعيش تجربة مستخدمك الحقيقي.

الهدف ليس فهم ما يقوله الناس، بل فهم ما يشعرون به وما يواجهونه فعلاً.

في هذه المرحلة ستتعلم:
• كيفية إجراء مقابلات مستخدمين فعّالة
• تقنية الملاحظة الميدانية
• بناء خريطة التعاطف

تذكر: لا تحكم، لا تفترض، فقط استمع وراقب.`,
  },
  define: {
    intro: `مرحلة تحديد المشكلة تحوّل بياناتك الخام إلى رؤية واضحة.

بعد أن تعاطفت مع مستخدمك، الآن تصيغ المشكلة الحقيقية بدقة.

في هذه المرحلة ستتعلم:
• كيفية كتابة عبارة POV قوية
• تقنية أسئلة "كيف يمكننا؟" HMW
• تحديد الرؤى الأعمق من بياناتك

المشكلة المحددة جيداً = حل أفضل بكثير.`,
  },
  ideate: {
    intro: `مرحلة توليد الأفكار هي المتعة الحقيقية! هنا لا قيود، لا انتقاد، فقط إبداع بلا حدود.

القاعدة الذهبية: الكمية أولاً، الجودة لاحقاً.

في هذه المرحلة ستتعلم:
• تقنيات العصف الذهني المتقدمة
• تطبيق SCAMPER لتطوير الأفكار
• اختيار الأفكار الأكثر قيمة للنمذجة

هدفك: 50 فكرة قبل أن تختار واحدة!`,
  },
  prototype: {
    intro: `مرحلة النمذجة: "ابنِ لتفكّر، لا تفكّر لتبني!"

النموذج الأولي لا يجب أن يكون مثالياً - يجب أن يكون سريعاً وقابلاً للاختبار.

في هذه المرحلة ستتعلم:
• أنواع النماذج الأولية المختلفة
• كيفية استخدام أدوات Makerspace
• بناء نموذج ورقي في 15 دقيقة

ابدأ بأبسط نسخة ممكنة من فكرتك.`,
  },
  test: {
    intro: `مرحلة الاختبار: ضع نموذجك أمام مستخدمين حقيقيين!

هذه المرحلة تكشف الحقيقة - هل حللت المشكلة فعلاً؟

في هذه المرحلة ستتعلم:
• تصميم سيناريو اختبار فعّال
• كيفية ملاحظة المستخدمين دون التدخل
• تحليل النتائج واستخلاص الدروس

تذكر: أنت تختبر المنتج، لا المستخدم.`,
  },
  iterate: {
    intro: `مرحلة التطوير: كل اختبار يُعلّمك، كل تكرار يُقرّبك!

التكرار ليس فشلاً - هو قلب منهجية التفكير التصميمي.

في هذه المرحلة ستتعلم:
• كيفية تحديد أولويات التحسينات
• بناء نسخة محسّنة من نموذجك
• التأمل في رحلتك وما تعلمته

أنت على وشك إتمام دورة كاملة من التفكير التصميمي!`,
  },
}

const MOCK_QUIZ: Record<StageKey, QuizQuestion[]> = {
  empathy: [
    { id: 'e1', stage_name: 'empathy', question_ar: 'ما الهدف الرئيسي من مرحلة التعاطف؟', type: 'mcq', options: ['جمع البيانات الكمية', 'فهم تجربة المستخدم عمقاً', 'تحديد الميزانية', 'اختيار التقنية المناسبة'], correct_answer: 'فهم تجربة المستخدم عمقاً', explanation_ar: 'مرحلة التعاطف تهدف لفهم الإنسان، ليس جمع الأرقام.' },
    { id: 'e2', stage_name: 'empathy', question_ar: 'ما الفرق بين ما يقوله المستخدم وما يفعله؟', type: 'mcq', options: ['لا فرق', 'المهم ما يقوله فقط', 'الفجوة بينهما تكشف الرؤى الحقيقية', 'المهم ما يفعله فقط'], correct_answer: 'الفجوة بينهما تكشف الرؤى الحقيقية', explanation_ar: 'الفجوة بين القول والفعل هي مصدر أهم الرؤى في التفكير التصميمي.' },
    { id: 'e3', stage_name: 'empathy', question_ar: 'خريطة التعاطف تتكون من كم محور؟', type: 'mcq', options: ['2', '4', '6', '8'], correct_answer: '4', explanation_ar: 'المحاور الأربعة: يفكر، يشعر، يقول، يفعل (بالإضافة لآلامه ومكاسبه).' },
    { id: 'e4', stage_name: 'empathy', question_ar: 'أي نوع من الأسئلة أفضل في مقابلة المستخدم؟', type: 'mcq', options: ['أسئلة نعم/لا', 'أسئلة مفتوحة', 'أسئلة تقنية', 'أسئلة مغلقة'], correct_answer: 'أسئلة مفتوحة', explanation_ar: 'الأسئلة المفتوحة تشجع المستخدم على مشاركة تجربته بعمق.' },
    { id: 'e5', stage_name: 'empathy', question_ar: 'الملاحظة الميدانية تعني:', type: 'mcq', options: ['قراءة الكتب عن المستخدمين', 'مراقبة المستخدمين في بيئتهم الطبيعية', 'إرسال استبيانات', 'تحليل البيانات الرقمية'], correct_answer: 'مراقبة المستخدمين في بيئتهم الطبيعية', explanation_ar: 'الملاحظة الميدانية تعني الانغماس في بيئة المستخدم الحقيقية.' },
    { id: 'e6', stage_name: 'empathy', question_ar: 'التعاطف في التفكير التصميمي يعني:', type: 'mcq', options: ['الشفقة على المستخدمين', 'وضع نفسك مكان المستخدم وفهم تجربته', 'مساعدة المستخدمين مالياً', 'الموافقة على كل ما يطلبه المستخدم'], correct_answer: 'وضع نفسك مكان المستخدم وفهم تجربته', explanation_ar: 'التعاطف يعني الفهم العميق، ليس الشفقة.' },
    { id: 'e7', stage_name: 'empathy', question_ar: 'كم عدد المستخدمين الموصى بمقابلتهم في هذه المرحلة؟', type: 'mcq', options: ['1', '3-5', '10-20', '100+'], correct_answer: '3-5', explanation_ar: '3-5 مستخدمين كافيون للكشف عن الأنماط الرئيسية.' },
    { id: 'e8', stage_name: 'empathy', question_ar: '"Insight" أو الرؤية هي:', type: 'mcq', options: ['ملاحظة مباشرة', 'رأي شخصي', 'تفسير عميق لسبب سلوك المستخدم', 'بيانات إحصائية'], correct_answer: 'تفسير عميق لسبب سلوك المستخدم', explanation_ar: 'الرؤية تفسّر "لماذا" يتصرف المستخدم بطريقة معينة.' },
    { id: 'e9', stage_name: 'empathy', question_ar: 'هل يجب التحقق من افتراضاتك المسبقة في مرحلة التعاطف؟', type: 'true_false', options: ['نعم، وربما تجد أنها خاطئة', 'لا، الافتراضات المسبقة موثوقة'], correct_answer: 'نعم، وربما تجد أنها خاطئة', explanation_ar: 'كثير من الافتراضات المسبقة تثبت خطأها بعد التعاطف الحقيقي.' },
    { id: 'e10', stage_name: 'empathy', question_ar: 'أفضل وقت لكتابة الملاحظات الميدانية:', type: 'mcq', options: ['بعد أسبوع من المشاهدة', 'أثناء المشاهدة أو فوراً بعدها', 'عندما تتذكر', 'قبل المشاهدة'], correct_answer: 'أثناء المشاهدة أو فوراً بعدها', explanation_ar: 'التفاصيل تُنسى بسرعة - دوّن ملاحظاتك فوراً.' },
  ],
  define: [
    { id: 'd1', stage_name: 'define', question_ar: 'عبارة POV تتكون من:', type: 'mcq', options: ['مستخدم + حل + تقنية', 'مستخدم + حاجة + رؤية', 'مشكلة + ميزانية + جدول', 'فكرة + تنفيذ + نتائج'], correct_answer: 'مستخدم + حاجة + رؤية', explanation_ar: 'صيغة POV: [مستخدم] يحتاج [حاجة] لأن [رؤية].' },
    { id: 'd2', stage_name: 'define', question_ar: 'HMW تعني:', type: 'mcq', options: ['How Much Work', 'How Might We', 'Help Me Win', 'Human Made Way'], correct_answer: 'How Might We', explanation_ar: 'HMW = كيف يمكننا؟ - لإعادة صياغة المشكلة كفرصة.' },
    { id: 'd3', stage_name: 'define', question_ar: 'الغرض من أسئلة HMW هو:', type: 'mcq', options: ['تحديد الميزانية', 'تضييق نطاق الحل', 'فتح أفق التفكير الإبداعي', 'تحديد المسؤوليات'], correct_answer: 'فتح أفق التفكير الإبداعي', explanation_ar: 'أسئلة HMW تحوّل المشكلة إلى فرصة وتفتح باب الأفكار.' },
    { id: 'd4', stage_name: 'define', question_ar: 'الرؤية (Insight) في POV يجب أن:', type: 'mcq', options: ['تكون طويلة ومفصّلة', 'تبدأ بـ "سأبني"', 'تفسّر السبب العميق وراء الحاجة', 'تذكر الحل المقترح'], correct_answer: 'تفسّر السبب العميق وراء الحاجة', explanation_ar: 'الرؤية تجيب على "لماذا" العميقة، لا "ماذا".' },
    { id: 'd5', stage_name: 'define', question_ar: 'الحد الأدنى لأسئلة HMW في قالب شكّل هو:', type: 'mcq', options: ['1', '3', '5', '10'], correct_answer: '5', explanation_ar: 'تحتاج 5 أسئلة HMW على الأقل لفتح آفاق كافية.' },
    { id: 'd6', stage_name: 'define', question_ar: 'إذا كان سؤال HMW ضيقاً جداً:', type: 'mcq', options: ['يفتح أكثر من اللازم', 'يقيّد التفكير الإبداعي', 'يسهّل الحل', 'ليس له أثر'], correct_answer: 'يقيّد التفكير الإبداعي', explanation_ar: 'السؤال الضيق جداً يفترض الحل مسبقاً ويقيّد الإبداع.' },
    { id: 'd7', stage_name: 'define', question_ar: 'الفرق بين المشكلة والعرض (Symptom):', type: 'mcq', options: ['لا فرق بينهما', 'العرض هو السبب الجذري', 'العرض ظاهر، المشكلة هي السبب الجذري', 'المشكلة أبسط من العرض'], correct_answer: 'العرض ظاهر، المشكلة هي السبب الجذري', explanation_ar: 'التفكير التصميمي يبحث عن المشكلة الجذرية وراء الأعراض الظاهرة.' },
    { id: 'd8', stage_name: 'define', question_ar: 'تقنية "5 لماذا؟" تُستخدم في:', type: 'mcq', options: ['بناء النموذج', 'إجراء الاختبار', 'الوصول للسبب الجذري للمشكلة', 'تحليل التكلفة'], correct_answer: 'الوصول للسبب الجذري للمشكلة', explanation_ar: 'سؤال "لماذا؟" 5 مرات يصل للسبب الجذري الحقيقي.' },
    { id: 'd9', stage_name: 'define', question_ar: 'هل يمكن للمشروع العودة لمرحلة التعاطف بعد التعريف؟', type: 'true_false', options: ['نعم، التفكير التصميمي غير خطي', 'لا، يجب المضي قدماً'], correct_answer: 'نعم، التفكير التصميمي غير خطي', explanation_ar: 'التفكير التصميمي مرن - يمكن العودة لأي مرحلة عند الحاجة.' },
    { id: 'd10', stage_name: 'define', question_ar: 'أفضل عبارة POV:', type: 'mcq', options: ['سأبني تطبيقاً للطلاب', 'طالب يحتاج تطبيقاً', 'محمد الطالب يحتاج تنظيم وقته لأنه يفقد التركيز بعد 20 دقيقة', 'المشكلة في التعليم'], correct_answer: 'محمد الطالب يحتاج تنظيم وقته لأنه يفقد التركيز بعد 20 دقيقة', explanation_ar: 'POV الجيد محدد ويذكر الشخص والحاجة والسبب.' },
  ],
  ideate: [
    { id: 'i1', stage_name: 'ideate', question_ar: 'في جلسة العصف الذهني، القاعدة الأهم هي:', type: 'mcq', options: ['جودة الأفكار قبل كميتها', 'الكمية قبل الجودة', 'الانتقاد المبكر للأفكار', 'التركيز على فكرة واحدة فقط'], correct_answer: 'الكمية قبل الجودة', explanation_ar: 'الكمية تقود للجودة - لا تحكم على الأفكار في مرحلة التوليد.' },
    { id: 'i2', stage_name: 'ideate', question_ar: 'SCAMPER اختصار لـ:', type: 'mcq', options: ['7 تقنيات لتطوير الأفكار', '7 مراحل للتصميم', '7 أنواع من المستخدمين', '7 خطوات للاختبار'], correct_answer: '7 تقنيات لتطوير الأفكار', explanation_ar: 'SCAMPER: Substitute, Combine, Adapt, Modify, Put to use, Eliminate, Reverse.' },
    { id: 'i3', stage_name: 'ideate', question_ar: 'لماذا نؤجل الحكم على الأفكار في مرحلة التوليد؟', type: 'mcq', options: ['لتوفير الوقت', 'لأن الانتقاد يقتل الإبداع', 'لأن جميع الأفكار جيدة', 'لأسباب سياسية'], correct_answer: 'لأن الانتقاد يقتل الإبداع', explanation_ar: 'الانتقاد المبكر يمنع ظهور الأفكار الجريئة والمبتكرة.' },
    { id: 'i4', stage_name: 'ideate', question_ar: 'بعد توليد الأفكار، تختار الأفضل بناءً على:', type: 'mcq', options: ['التكلفة فقط', 'الإمكانية والتأثير على المستخدم', 'رأي المدير', 'الفكرة الأولى'], correct_answer: 'الإمكانية والتأثير على المستخدم', explanation_ar: 'معيار الاختيار: هل يمكن تنفيذها؟ وهل تحل مشكلة المستخدم فعلاً؟' },
    { id: 'i5', stage_name: 'ideate', question_ar: 'تقنية "Crazy 8s" تعني:', type: 'mcq', options: ['8 مستخدمين للاختبار', 'رسم 8 أفكار في 8 دقائق', '8 خطوات للتصميم', '8 أنواع من النماذج'], correct_answer: 'رسم 8 أفكار في 8 دقائق', explanation_ar: 'Crazy 8s تجبرك على التفكير السريع وتوليد أفكار متعددة.' },
    { id: 'i6', stage_name: 'ideate', question_ar: 'أفضل الأفكار تأتي عادة:', type: 'mcq', options: ['في أول 5 أفكار', 'بعد استنفاد الأفكار الواضحة', 'من الكتب والمراجع', 'من المسابقات'], correct_answer: 'بعد استنفاد الأفكار الواضحة', explanation_ar: 'الأفكار الأولى واضحة ومتوقعة، الإبداع يأتي بعدها.' },
    { id: 'i7', stage_name: 'ideate', question_ar: '"How Might We" يستخدم في بداية:', type: 'mcq', options: ['مرحلة التعاطف', 'مرحلة النمذجة', 'مرحلة توليد الأفكار', 'مرحلة الاختبار'], correct_answer: 'مرحلة توليد الأفكار', explanation_ar: 'HMW يُستخدم كمنطلق لجلسات توليد الأفكار.' },
    { id: 'i8', stage_name: 'ideate', question_ar: 'هل الأفكار "المجنونة" مقبولة في العصف الذهني؟', type: 'true_false', options: ['نعم، وأحياناً تكون الأفضل', 'لا، يجب أن تكون منطقية'], correct_answer: 'نعم، وأحياناً تكون الأفضل', explanation_ar: 'الأفكار الجريئة قد تقود لحلول ثورية لم يفكر بها أحد.' },
    { id: 'i9', stage_name: 'ideate', question_ar: 'الهدف من مرحلة توليد الأفكار هو:', type: 'mcq', options: ['الوصول لحل نهائي', 'توسيع المساحة الممكنة للحلول', 'تحليل المنافسين', 'تحديد التكلفة'], correct_answer: 'توسيع المساحة الممكنة للحلول', explanation_ar: 'نوسّع أولاً ثم نضيّق - هذا قلب التفكير التصميمي.' },
    { id: 'i10', stage_name: 'ideate', question_ar: 'التصويت الصامت (Dot Voting) يُستخدم لـ:', type: 'mcq', options: ['اختيار الأفكار الأفضل جماعياً دون تأثير الآخرين', 'رفض الأفكار', 'تحديد الميزانية', 'توزيع المهام'], correct_answer: 'اختيار الأفكار الأفضل جماعياً دون تأثير الآخرين', explanation_ar: 'التصويت الصامت يمنع سيطرة أصوات معينة على القرار الجماعي.' },
  ],
  prototype: [
    { id: 'p1', stage_name: 'prototype', question_ar: 'الغرض الأساسي من النموذج الأولي هو:', type: 'mcq', options: ['الحصول على المنتج النهائي', 'التعلم بسرعة من الاختبار', 'إقناع المستثمرين', 'توفير التكاليف'], correct_answer: 'التعلم بسرعة من الاختبار', explanation_ar: 'النموذج أداة تعلم، ليس منتجاً نهائياً.' },
    { id: 'p2', stage_name: 'prototype', question_ar: '"ابنِ لتفكّر" يعني:', type: 'mcq', options: ['فكّر كثيراً قبل البناء', 'ابنِ النموذج لتكتشف المشاكل وتتعلم', 'انتظر حتى تجهز الفكرة', 'لا تبني حتى تتأكد'], correct_answer: 'ابنِ النموذج لتكتشف المشاكل وتتعلم', explanation_ar: 'البناء السريع يكشف مشاكل لا تستطيع اكتشافها بالتفكير فقط.' },
    { id: 'p3', stage_name: 'prototype', question_ar: 'النموذج الورقي مفيد لأنه:', type: 'mcq', options: ['يبدو احترافياً', 'سريع ورخيص وقابل للتعديل', 'متين ومقاوم', 'يناسب العرض النهائي'], correct_answer: 'سريع ورخيص وقابل للتعديل', explanation_ar: 'الورق يسمح بالتعديل السريع وبتكلفة صفرية.' },
    { id: 'p4', stage_name: 'prototype', question_ar: 'مصداقية النموذج (Fidelity) تزداد مع:', type: 'mcq', options: ['التقدم في التكرارات', 'البدء بالمشروع', 'تحديد الميزانية', 'توثيق المتطلبات'], correct_answer: 'التقدم في التكرارات', explanation_ar: 'ابدأ بنموذج بسيط (low-fi) وارفع تدريجياً مصداقيته.' },
    { id: 'p5', stage_name: 'prototype', question_ar: 'الخامة الأنسب للنموذج الأولي السريع:', type: 'mcq', options: ['معدن', 'ورق وكرتون', 'بلاستيك صلب', 'خشب'], correct_answer: 'ورق وكرتون', explanation_ar: 'الورق والكرتون سريع ورخيص ومثالي للنماذج الأولية.' },
    { id: 'p6', stage_name: 'prototype', question_ar: 'ما الذي يجب أن يختبره النموذج؟', type: 'mcq', options: ['كل شيء في آن واحد', 'فرضية محددة أو ميزة واحدة', 'المظهر فقط', 'التقنية فقط'], correct_answer: 'فرضية محددة أو ميزة واحدة', explanation_ar: 'ركّز كل نموذج على اختبار شيء محدد لنتائج أوضح.' },
    { id: 'p7', stage_name: 'prototype', question_ar: 'هل فشل النموذج في الاختبار أمر سيئ؟', type: 'true_false', options: ['لا، الفشل المبكر نجاح لأنه يوفر الوقت والمال', 'نعم، يعني المشروع فاشل'], correct_answer: 'لا، الفشل المبكر نجاح لأنه يوفر الوقت والمال', explanation_ar: 'الفشل المبكر أرخص من الفشل المتأخر.' },
    { id: 'p8', stage_name: 'prototype', question_ar: 'PLA في الطباعة ثلاثية الأبعاد مناسب:', type: 'mcq', options: ['للقطع المعرّضة للحرارة العالية', 'للمبتدئين', 'للقطع المعدنية', 'للطباعة تحت الماء'], correct_answer: 'للمبتدئين', explanation_ar: 'PLA سهل الطباعة وصديق للبيئة، مثالي للمبتدئين.' },
    { id: 'p9', stage_name: 'prototype', question_ar: 'قبل استخدام آلة الليزر، يجب:', type: 'mcq', options: ['التحقق من التهوية الجيدة فقط', 'التحقق من التهوية والإعدادات الصحيحة والإشراف المتخصص', 'لا شيء', 'الحصول على إذن فقط'], correct_answer: 'التحقق من التهوية والإعدادات الصحيحة والإشراف المتخصص', explanation_ar: 'السلامة أولاً دائماً في المختبر.' },
    { id: 'p10', stage_name: 'prototype', question_ar: 'وثّق عملية البناء:', type: 'mcq', options: ['بعد الانتهاء من الذاكرة', 'أثناء البناء', 'لا حاجة للتوثيق', 'قبل البدء فقط'], correct_answer: 'أثناء البناء', explanation_ar: 'التوثيق اللحظي يحفظ التفاصيل ويساعدك ويساعد الآخرين.' },
  ],
  test: [
    { id: 't1', stage_name: 'test', question_ar: 'الجملة الصحيحة لبداية جلسة الاختبار:', type: 'mcq', options: ['نحن نختبرك اليوم', 'نحن نختبر المنتج، لا أنت', 'هذا المنتج ممتاز، أليس كذلك؟', 'أخبرنا ما يعجبك'], correct_answer: 'نحن نختبر المنتج، لا أنت', explanation_ar: 'هذه الجملة تريح المستخدم وتجعله صريحاً.' },
    { id: 't2', stage_name: 'test', question_ar: 'الحد الأدنى لمستخدمي الاختبار في شكّل هو:', type: 'mcq', options: ['1', '2', '3', '10'], correct_answer: '3', explanation_ar: '3 مستخدمين يكشفون الأنماط الأساسية.' },
    { id: 't3', stage_name: 'test', question_ar: 'أثناء الاختبار، إذا كافح المستخدم مع المهمة:', type: 'mcq', options: ['تدخّل وساعده فوراً', 'راقب وسجّل الكفاح كمعلومة قيّمة', 'أوقف الاختبار', 'دافع عن تصميمك'], correct_answer: 'راقب وسجّل الكفاح كمعلومة قيّمة', explanation_ar: 'الكفاح يكشف نقاط الضعف الحقيقية في التصميم.' },
    { id: 't4', stage_name: 'test', question_ar: '"Think Aloud" يعني:', type: 'mcq', options: ['التفكير الجماعي', 'طلب المستخدم التفكير بصوت عالٍ', 'التصميم بصوت عالٍ', 'قراءة التعليمات بصوت'], correct_answer: 'طلب المستخدم التفكير بصوت عالٍ', explanation_ar: 'التفكير بصوت عالٍ يكشف عمليات تفكير المستخدم.' },
    { id: 't5', stage_name: 'test', question_ar: 'الاختبار يُقيّم:', type: 'mcq', options: ['الجماليات فقط', 'مدى حل المنتج للمشكلة الحقيقية', 'التكنولوجيا المستخدمة', 'تكلفة الإنتاج'], correct_answer: 'مدى حل المنتج للمشكلة الحقيقية', explanation_ar: 'الهدف التحقق من أن الحل يحل المشكلة فعلاً.' },
    { id: 't6', stage_name: 'test', question_ar: 'الأسئلة بعد الاختبار يجب أن تكون:', type: 'mcq', options: ['إيحائية', 'مفتوحة وغير إيحائية', 'تقنية', 'ترويجية'], correct_answer: 'مفتوحة وغير إيحائية', explanation_ar: 'الأسئلة الإيحائية تشوّه النتائج وتعطي معلومات غير دقيقة.' },
    { id: 't7', stage_name: 'test', question_ar: 'عدد 5 مستخدمين يكشف:', type: 'mcq', options: ['30% من المشاكل', '50% من المشاكل', '85% من المشاكل', '100% من المشاكل'], correct_answer: '85% من المشاكل', explanation_ar: 'الدراسات أثبتت أن 5 مستخدمين يكشفون 85% من مشاكل الاستخدام.' },
    { id: 't8', stage_name: 'test', question_ar: 'سجل اختبار موحّد يساعد في:', type: 'mcq', options: ['توفير الوقت فقط', 'مقارنة نتائج مستخدمين مختلفين بشكل منصف', 'تقليل عدد المستخدمين', 'إخفاء نتائج سيئة'], correct_answer: 'مقارنة نتائج مستخدمين مختلفين بشكل منصف', explanation_ar: 'التوحيد يتيح مقارنة أكثر موضوعية.' },
    { id: 't9', stage_name: 'test', question_ar: 'هل يجب شرح كيفية عمل المنتج للمستخدم قبل الاختبار؟', type: 'true_false', options: ['لا، راقب كيف يتعامل معه بشكل تلقائي', 'نعم دائماً'], correct_answer: 'لا، راقب كيف يتعامل معه بشكل تلقائي', explanation_ar: 'الاستخدام التلقائي يكشف ما إذا كان التصميم سهلاً وبديهياً.' },
    { id: 't10', stage_name: 'test', question_ar: 'أهم ما تبحث عنه في الاختبار:', type: 'mcq', options: ['الثناء والتقدير', 'الأنماط والمشاكل المتكررة عبر المستخدمين', 'رأي مستخدم واحد فقط', 'تأكيد أن فكرتك صحيحة'], correct_answer: 'الأنماط والمشاكل المتكررة عبر المستخدمين', explanation_ar: 'الأنماط المتكررة هي ما يستحق الإصلاح أولاً.' },
  ],
  iterate: [
    { id: 'it1', stage_name: 'iterate', question_ar: 'التكرار في التفكير التصميمي هو:', type: 'mcq', options: ['علامة فشل', 'قلب المنهجية وطريق للنجاح', 'خطوة اختيارية', 'إعادة من الصفر'], correct_answer: 'قلب المنهجية وطريق للنجاح', explanation_ar: 'التكرار هو ما يحوّل الأفكار إلى حلول ناجحة.' },
    { id: 'it2', stage_name: 'iterate', question_ar: 'ما أول شيء تفعله بعد الاختبار؟', type: 'mcq', options: ['ابنِ نسخة جديدة فوراً', 'حلّل النتائج وحدد الأولويات', 'أوقف المشروع', 'انشر المنتج'], correct_answer: 'حلّل النتائج وحدد الأولويات', explanation_ar: 'التحليل يحدد ما يستحق التغيير أولاً.' },
    { id: 'it3', stage_name: 'iterate', question_ar: 'كيف تحدد أولوية التحسينات؟', type: 'mcq', options: ['بشكل عشوائي', 'حسب التأثير على المستخدم وسهولة التنفيذ', 'حسب التكلفة فقط', 'حسب رأيك الشخصي فقط'], correct_answer: 'حسب التأثير على المستخدم وسهولة التنفيذ', explanation_ar: 'الأولوية للتحسينات ذات التأثير العالي والتكلفة المنخفضة.' },
    { id: 'it4', stage_name: 'iterate', question_ar: 'سجل التكرار يوثّق:', type: 'mcq', options: ['الأفكار الأولية فقط', 'التغييرات ولماذا أُجريت وما نتائجها', 'الميزانية فقط', 'اجتماعات الفريق'], correct_answer: 'التغييرات ولماذا أُجريت وما نتائجها', explanation_ar: 'التوثيق الجيد يبني على التجربة ويتجنب تكرار الأخطاء.' },
    { id: 'it5', stage_name: 'iterate', question_ar: 'التأمل في رحلة المشروع مهم لأنه:', type: 'mcq', options: ['للحصول على شهادة فقط', 'يحوّل التجربة لتعلم دائم وقابل للنقل', 'إجراء إداري فقط', 'لا فائدة منه'], correct_answer: 'يحوّل التجربة لتعلم دائم وقابل للنقل', explanation_ar: 'التأمل يجعل التجربة درساً يستفيد منه في المشاريع القادمة.' },
    { id: 'it6', stage_name: 'iterate', question_ar: 'متى تتوقف عن التكرار؟', type: 'mcq', options: ['بعد أول تكرار', 'عندما يحل المنتج المشكلة بشكل مُرضٍ', 'لا تتوقف أبداً', 'بعد سنة'], correct_answer: 'عندما يحل المنتج المشكلة بشكل مُرضٍ', explanation_ar: 'الهدف هو الحل المُرضي، لا الكمال المستحيل.' },
    { id: 'it7', stage_name: 'iterate', question_ar: 'إذا أشار الاختبار لمشكلة في التعريف الأصلي:', type: 'mcq', options: ['تجاهل المشكلة', 'عُد لمرحلة تحديد المشكلة', 'أوقف المشروع', 'واصل دون تعديل'], correct_answer: 'عُد لمرحلة تحديد المشكلة', explanation_ar: 'المرونة هي قوة التفكير التصميمي - العودة ليست فشلاً.' },
    { id: 'it8', stage_name: 'iterate', question_ar: 'الإصدار المحسّن يجب أن يُختبر:', type: 'true_false', options: ['نعم، مع مستخدمين جدد إذا أمكن', 'لا، الاختبار مرة واحدة يكفي'], correct_answer: 'نعم، مع مستخدمين جدد إذا أمكن', explanation_ar: 'كل تكرار يستحق اختباراً للتحقق من التحسن.' },
    { id: 'it9', stage_name: 'iterate', question_ar: 'التفكير التصميمي مقارنةً بالمنهجية التقليدية:', type: 'mcq', options: ['أبطأ وأكثر تكلفة', 'أسرع في الوصول لحلول تناسب المستخدم', 'متشابهان تماماً', 'أقل دقة'], correct_answer: 'أسرع في الوصول لحلول تناسب المستخدم', explanation_ar: 'الفشل المبكر والتكرار السريع يوصلان لحلول أفضل في وقت أقل.' },
    { id: 'it10', stage_name: 'iterate', question_ar: 'ما الذي يميّز المبتكر الناجح؟', type: 'mcq', options: ['الحصول على الفكرة المثالية من أول محاولة', 'التعلم السريع من كل تجربة والمثابرة', 'العمل بمفرده', 'تجنب المخاطرة'], correct_answer: 'التعلم السريع من كل تجربة والمثابرة', explanation_ar: 'التعلم السريع والمثابرة هما سر المبتكرين الناجحين.' },
  ],
}

export default function StagePage({ params }: Props) {
  const router = useRouter()
  const { projectId, stage } = params

  const stageKey = stage as StageKey
  const [activeTab, setActiveTab] = useState('learn')
  const [templates, setTemplates] = useState<Template[]>([])
  const [submissions, setSubmissions] = useState<TemplateSubmission[]>([])
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null)
  const [selectedSubmission, setSelectedSubmission] = useState<TemplateSubmission | undefined>()
  const [project, setProject] = useState<Project | null>(null)
  const [stageData, setStageData] = useState<ProjectStage | null>(null)
  const [loading, setLoading] = useState(true)
  const [credits, setCredits] = useState(10)
  const [contentViewed, setContentViewed] = useState(false)

  const stageIndex = STAGE_ORDER.indexOf(stageKey)
  const stageContent = STAGE_CONTENT[stageKey]
  const requiredTemplates = STAGE_TEMPLATES[stageKey] || []
  const quizQuestions = MOCK_QUIZ[stageKey] || []

  useEffect(() => {
    async function load() {
      const supabase = createClient()
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) { router.push('/login'); return }

      const [
        { data: proj },
        { data: stage_data },
        { data: tmpl },
        { data: subs },
        { data: user },
      ] = await Promise.all([
        supabase.from('projects').select('*').eq('id', projectId).eq('user_id', session.user.id).single(),
        supabase.from('project_stages').select('*').eq('project_id', projectId).eq('stage_name', stageKey).single(),
        supabase.from('templates').select('*').in('name', requiredTemplates),
        supabase.from('template_submissions').select('*').eq('project_id', projectId).eq('user_id', session.user.id),
        supabase.from('users').select('ai_credits').eq('id', session.user.id).single(),
      ])

      if (!proj) { router.push('/dashboard'); return }

      setProject(proj)
      setStageData(stage_data)
      setTemplates(tmpl || [])
      setSubmissions(subs || [])
      if (user) setCredits(user.ai_credits)
      if (stage_data?.content_viewed) setContentViewed(true)
      setLoading(false)
    }
    load()
  }, [projectId, stageKey, router, requiredTemplates])

  async function handleContentViewed() {
    if (contentViewed) return
    setContentViewed(true)
    const supabase = createClient()
    await supabase
      .from('project_stages')
      .update({ content_viewed: true })
      .eq('project_id', projectId)
      .eq('stage_name', stageKey)
  }

  function handleTemplateOpen(template: Template) {
    const sub = submissions.find(s => s.template_id === template.id)
    setSelectedTemplate(template)
    setSelectedSubmission(sub)
  }

  async function handleTemplateSubmitted(templateName: string) {
    const supabase = createClient()
    const updated = [...(stageData?.templates_submitted || []), templateName]

    await supabase
      .from('project_stages')
      .update({ templates_submitted: [...new Set(updated)] })
      .eq('project_id', projectId)
      .eq('stage_name', stageKey)

    // Refresh submissions
    const { data: { session } } = await supabase.auth.getSession()
    if (session) {
      const { data: subs } = await supabase
        .from('template_submissions')
        .select('*')
        .eq('project_id', projectId)
        .eq('user_id', session.user.id)
      setSubmissions(subs || [])
      setStageData(prev => prev ? { ...prev, templates_submitted: [...new Set(updated)] } : null)
    }
  }

  async function handleQuizPass(score: number) {
    const supabase = createClient()
    await supabase
      .from('project_stages')
      .update({ assessment_score: score, assessment_passed: true, completed_at: new Date().toISOString() })
      .eq('project_id', projectId)
      .eq('stage_name', stageKey)
    setStageData(prev => prev ? { ...prev, assessment_passed: true, assessment_score: score } : null)
  }

  async function handleNextStage() {
    const nextStageIndex = stageIndex + 1
    if (nextStageIndex >= STAGE_ORDER.length) {
      router.push('/dashboard')
      return
    }
    const nextStage = STAGE_ORDER[nextStageIndex]
    const supabase = createClient()
    await supabase.from('projects').update({ current_stage: nextStage }).eq('id', projectId)
    await supabase
      .from('project_stages')
      .update({ unlocked_at: new Date().toISOString() })
      .eq('project_id', projectId)
      .eq('stage_name', nextStage)
    router.push(`/portal/${projectId}/${nextStage}`)
  }

  const submittedNames = new Set((stageData?.templates_submitted || []))
  const allTemplatesSubmitted = requiredTemplates.every(t => submittedNames.has(t))
  const assessmentPassed = stageData?.assessment_passed || false
  const canUnlock = contentViewed && allTemplatesSubmitted && assessmentPassed

  const checklistItems = [
    { label: 'مشاهدة المحتوى التعليمي', done: contentViewed },
    { label: `تسليم جميع القوالب (${submittedNames.size}/${requiredTemplates.length})`, done: allTemplatesSubmitted },
    { label: 'اجتياز التقييم بـ 90% أو أكثر', done: assessmentPassed },
  ]

  const tabs = [
    { id: 'learn', label: 'التعلم', icon: '📖' },
    { id: 'templates', label: 'القوالب', icon: '📝' },
    { id: 'assessment', label: 'التقييم', icon: '✅' },
  ]

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-cream">
        <div className="text-center">
          <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-ink-muted">جارٍ التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-cream" dir="rtl">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="max-w-5xl mx-auto px-6 py-8">
          <StageHeader
            stage={stageKey}
            projectTitle={project?.title || 'مشروعي'}
            stageIndex={stageIndex}
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <TabNav tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

              {/* Learn Tab */}
              {activeTab === 'learn' && (
                <div className="bg-white rounded-xl border border-cream-dark p-6">
                  <div className="aspect-video bg-primary/5 rounded-xl flex items-center justify-center mb-6 border border-primary/10">
                    <div className="text-center text-ink-muted">
                      <div className="text-4xl mb-2">🎬</div>
                      <p className="font-medium">فيديو مرحلة {STAGE_NAMES_AR[stageKey]}</p>
                      <p className="text-sm mt-1">قريباً</p>
                    </div>
                  </div>

                  <div className="prose prose-sm max-w-none text-ink">
                    <h3 className="font-bold text-xl text-primary mb-4">
                      {STAGE_ICONS[stageKey]} {STAGE_NAMES_AR[stageKey]}
                    </h3>
                    <div className="whitespace-pre-line text-ink-light leading-relaxed">
                      {stageContent?.intro}
                    </div>
                  </div>

                  {!contentViewed && (
                    <button
                      onClick={handleContentViewed}
                      className="mt-6 w-full bg-primary text-white py-3 rounded-[10px] font-bold hover:bg-primary-dark transition-colors"
                    >
                      ✓ قرأت المحتوى وجاهز للتطبيق
                    </button>
                  )}
                  {contentViewed && (
                    <div className="mt-4 bg-green-50 border border-green-200 text-green-700 rounded-[10px] p-3 text-sm text-center">
                      ✅ تم وضع علامة "تمت المشاهدة"
                    </div>
                  )}
                </div>
              )}

              {/* Templates Tab */}
              {activeTab === 'templates' && (
                <div className="space-y-4">
                  <p className="text-sm text-ink-muted">
                    أكمل جميع القوالب التالية للمضي قدماً ({submittedNames.size}/{requiredTemplates.length} مُسلَّمة)
                  </p>
                  {templates.length === 0 ? (
                    <div className="bg-white border border-cream-dark rounded-xl p-8 text-center text-ink-muted">
                      جارٍ تحميل القوالب...
                    </div>
                  ) : (
                    templates.map((template) => {
                      const sub = submissions.find(s => s.template_id === template.id)
                      return (
                        <TemplateCard
                          key={template.id}
                          template={template}
                          submission={sub}
                          onOpen={handleTemplateOpen}
                        />
                      )
                    })
                  )}
                </div>
              )}

              {/* Assessment Tab */}
              {activeTab === 'assessment' && (
                <div>
                  <p className="text-sm text-ink-muted mb-4">
                    أجب على الأسئلة التالية. تحتاج 90% أو أكثر للنجاح.
                  </p>
                  <InlineQuiz
                    questions={quizQuestions}
                    onPass={handleQuizPass}
                    onFail={(score) => console.log('Failed:', score)}
                    alreadyPassed={assessmentPassed}
                    lastScore={stageData?.assessment_score}
                  />
                </div>
              )}
            </div>

            {/* Right sidebar */}
            <div className="space-y-6">
              <StageChecklist
                items={checklistItems}
                canUnlock={canUnlock}
                onNext={handleNextStage}
              />
              <AIMentorPanel
                credits={credits}
                projectId={projectId}
                hint={`أنت في مرحلة ${STAGE_NAMES_AR[stageKey]}. كيف يمكنني مساعدتك؟`}
              />
            </div>
          </div>
        </div>
      </main>

      <TemplateModal
        template={selectedTemplate}
        submission={selectedSubmission}
        projectId={projectId}
        onClose={() => { setSelectedTemplate(null); setSelectedSubmission(undefined) }}
        onSubmitted={handleTemplateSubmitted}
      />
    </div>
  )
}
