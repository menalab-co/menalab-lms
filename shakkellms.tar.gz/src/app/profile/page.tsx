import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Sidebar from '@/components/layout/Sidebar'
import LevelBadge from '@/components/dashboard/LevelBadge'
import ProgressBar from '@/components/ui/ProgressBar'
import { BADGE_DEFINITIONS } from '@/lib/types'
import { getLevelProgress, getXPToNextLevel } from '@/lib/xp'

export default async function ProfilePage() {
  const supabase = createClient()
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) redirect('/login')

  const [{ data: user }, { data: badges }, { data: submissions }] = await Promise.all([
    supabase.from('users').select('*').eq('id', session.user.id).single(),
    supabase.from('badges').select('*').eq('user_id', session.user.id),
    supabase.from('template_submissions').select('*, templates(title_ar, icon)').eq('user_id', session.user.id).eq('status', 'submitted').order('updated_at', { ascending: false }).limit(10),
  ])

  const userData = user || { name: session.user.email?.split('@')[0] || 'مستخدم', xp: 0, level: 1, ai_credits: 10, max_credits: 10, streak: 0, email: session.user.email || '' }
  const earnedBadgeSlugs = new Set((badges || []).map((b: { badge_slug: string }) => b.badge_slug))
  const initials = userData.name?.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase() || 'م'

  return (
    <div className="flex min-h-screen bg-cream" dir="rtl">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <h1 className="text-3xl font-bold text-ink mb-8">الملف الشخصي</h1>

          {/* Profile card */}
          <div className="bg-white border border-cream-dark rounded-xl p-8 mb-8">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
              <div className="w-24 h-24 rounded-full bg-primary text-white flex items-center justify-center text-3xl font-bold flex-shrink-0">
                {initials}
              </div>
              <div className="flex-1 text-center sm:text-right">
                <h2 className="text-2xl font-bold text-ink mb-1">{userData.name}</h2>
                <p className="text-ink-muted mb-3">{userData.email}</p>
                <LevelBadge xp={userData.xp} size="md" />
                <div className="mt-4 max-w-xs">
                  <ProgressBar value={getLevelProgress(userData.xp)} label="التقدم للمستوى التالي" showLabel height="md" />
                  <p className="text-xs text-ink-muted mt-1">يتبقى {getXPToNextLevel(userData.xp)} نقطة</p>
                </div>
              </div>
              <div className="flex flex-col gap-3 text-center">
                <div className="bg-cream rounded-xl p-4">
                  <p className="text-2xl font-bold text-primary">{userData.xp}</p>
                  <p className="text-xs text-ink-muted">نقطة XP</p>
                </div>
                <div className="bg-cream rounded-xl p-4">
                  <p className="text-2xl font-bold text-accent">{userData.streak}</p>
                  <p className="text-xs text-ink-muted">🔥 أيام</p>
                </div>
              </div>
            </div>
          </div>

          {/* Badges */}
          <div className="bg-white border border-cream-dark rounded-xl p-6 mb-8">
            <h3 className="font-bold text-ink text-xl mb-4">الشارات ({badges?.length || 0}/{BADGE_DEFINITIONS.length})</h3>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
              {BADGE_DEFINITIONS.map(badge => {
                const earned = earnedBadgeSlugs.has(badge.slug)
                return (
                  <div
                    key={badge.slug}
                    title={badge.description}
                    className={`flex flex-col items-center p-4 rounded-xl text-center transition-all ${
                      earned ? 'bg-accent/10 border border-accent/30' : 'bg-cream-dark opacity-40'
                    }`}
                  >
                    <div className="text-3xl mb-2">{badge.icon}</div>
                    <p className="text-xs font-medium text-ink leading-tight">{badge.name_ar}</p>
                    {earned && <p className="text-xs text-primary mt-1">✓</p>}
                  </div>
                )
              })}
            </div>
          </div>

          {/* Recent submissions */}
          {submissions && submissions.length > 0 && (
            <div className="bg-white border border-cream-dark rounded-xl p-6">
              <h3 className="font-bold text-ink text-xl mb-4">القوالب المسلّمة</h3>
              <div className="space-y-3">
                {submissions.map((s: { id: string; templates: { title_ar: string; icon: string } | null; updated_at: string }) => (
                  <div key={s.id} className="flex items-center gap-3 p-3 bg-cream rounded-[10px]">
                    <span className="text-xl">{s.templates?.icon || '📝'}</span>
                    <span className="text-sm font-medium text-ink">{s.templates?.title_ar}</span>
                    <span className="text-xs text-ink-muted mr-auto">
                      {new Date(s.updated_at).toLocaleDateString('ar-SA')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
