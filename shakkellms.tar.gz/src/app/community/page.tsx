'use client'

import { useState } from 'react'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import Modal from '@/components/ui/Modal'
import Button from '@/components/ui/Button'
import Badge from '@/components/ui/Badge'

const MOCK_POSTS = [
  { id: '1', author: 'فهد ع.', tag: 'التعاطف', title: 'كيف أجري مقابلة مع شخص خجول؟', votes: 24, replies: 7, solved: true, time: 'منذ ساعتين', body: 'لدي مشكلة أن كثيراً من المستخدمين الذين أقابلهم يكونون خجولين وصعوبة في التعبير...' },
  { id: '2', author: 'سارة م.', tag: 'تحديد المشكلة', title: 'ما الفرق بين POV و HMW؟', votes: 18, replies: 5, solved: false, time: 'منذ 5 ساعات', body: 'أربكني الفرق بين عبارة POV وأسئلة HMW، هل يمكن شرح الفرق بمثال؟' },
  { id: '3', author: 'عمر ش.', tag: 'النمذجة', title: 'ما الفرق بين النمذجة الورقية والرقمية؟', votes: 31, replies: 12, solved: true, time: 'أمس', body: 'متى أستخدم النموذج الورقي ومتى أنتقل للرقمي؟' },
  { id: '4', author: 'نورة ق.', tag: 'توليد الأفكار', title: 'نصائح لجلسة عصف ذهني فعّالة عبر الإنترنت', votes: 15, replies: 4, solved: false, time: 'منذ يومين', body: 'فريقي بعيد جغرافياً، كيف ننظم جلسات عصف ذهني فعّالة؟' },
  { id: '5', author: 'خالد ع.', tag: 'الاختبار', title: 'كم مستخدماً كافٍ لاختبار النموذج؟', votes: 22, replies: 8, solved: true, time: 'منذ 3 أيام', body: 'هل 3 مستخدمين كافيون أم أحتاج أكثر؟' },
  { id: '6', author: 'منى ه.', tag: 'التطوير', title: 'كيف أحدد أولوية التحسينات بعد الاختبار؟', votes: 9, replies: 3, solved: false, time: 'منذ أسبوع', body: 'لدي قائمة طويلة من التحسينات بعد الاختبار، كيف أحدد من أين أبدأ؟' },
]

const TAGS = ['الكل', 'التعاطف', 'تحديد المشكلة', 'توليد الأفكار', 'النمذجة', 'الاختبار', 'التطوير']

export default function CommunityPage() {
  const [activeTag, setActiveTag] = useState('الكل')
  const [newPostModal, setNewPostModal] = useState(false)
  const [newTitle, setNewTitle] = useState('')
  const [newBody, setNewBody] = useState('')
  const [newTag, setNewTag] = useState('')
  const [posts, setPosts] = useState(MOCK_POSTS)
  const [votedIds, setVotedIds] = useState<Set<string>>(new Set())

  const filtered = posts.filter(p => activeTag === 'الكل' || p.tag === activeTag)

  function handleVote(id: string) {
    if (votedIds.has(id)) return
    setVotedIds(prev => new Set([...prev, id]))
    setPosts(prev => prev.map(p => p.id === id ? { ...p, votes: p.votes + 1 } : p))
  }

  function handleNewPost() {
    if (!newTitle.trim() || !newBody.trim()) return
    const post = {
      id: Date.now().toString(), author: 'أنت',
      tag: newTag || 'عام', title: newTitle, votes: 0,
      replies: 0, solved: false, time: 'الآن', body: newBody,
    }
    setPosts(prev => [post, ...prev])
    setNewPostModal(false)
    setNewTitle(''); setNewBody(''); setNewTag('')
  }

  return (
    <div className="min-h-screen bg-cream" dir="rtl">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-ink mb-2">المجتمع</h1>
            <p className="text-ink-muted">تعلّم من تجارب الآخرين وشارك خبرتك</p>
          </div>
          <Button onClick={() => setNewPostModal(true)}>+ منشور جديد</Button>
        </div>

        {/* Tags filter */}
        <div className="flex gap-2 flex-wrap mb-6">
          {TAGS.map(tag => (
            <button
              key={tag}
              onClick={() => setActiveTag(tag)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                activeTag === tag ? 'bg-primary text-white' : 'bg-white border border-cream-dark text-ink-light hover:border-primary hover:text-primary'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {filtered.map(post => (
            <div key={post.id} className="bg-white border border-cream-dark rounded-xl p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start gap-4">
                {/* Vote */}
                <button
                  onClick={() => handleVote(post.id)}
                  className={`flex flex-col items-center gap-0.5 text-sm font-bold transition-colors flex-shrink-0 ${
                    votedIds.has(post.id) ? 'text-primary' : 'text-ink-muted hover:text-primary'
                  }`}
                >
                  <span className="text-lg">▲</span>
                  <span>{post.votes}</span>
                </button>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <Badge variant="primary" size="sm">{post.tag}</Badge>
                    {post.solved && <Badge variant="success" size="sm">✓ محلول</Badge>}
                    <span className="text-xs text-ink-muted mr-auto">{post.author} • {post.time}</span>
                  </div>
                  <h3 className="font-bold text-ink text-lg mb-1">{post.title}</h3>
                  <p className="text-ink-muted text-sm line-clamp-2">{post.body}</p>
                  <div className="flex items-center gap-3 mt-3 text-xs text-ink-muted">
                    <span>💬 {post.replies} رد</span>
                    <button className="text-primary hover:underline">قرأ المزيد</button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
      <Footer />

      <Modal open={newPostModal} onClose={() => setNewPostModal(false)} title="منشور جديد" size="md">
        <div className="p-6" dir="rtl">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">العنوان</label>
              <input
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                placeholder="عنوان سؤالك أو موضوعك..."
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">التفاصيل</label>
              <textarea
                value={newBody}
                onChange={e => setNewBody(e.target.value)}
                rows={4}
                placeholder="اشرح بالتفصيل..."
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary transition-colors resize-none"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-ink mb-1.5">التصنيف</label>
              <select
                value={newTag}
                onChange={e => setNewTag(e.target.value)}
                className="w-full border border-cream-dark rounded-[10px] px-4 py-3 text-ink bg-cream focus:outline-none focus:border-primary transition-colors"
              >
                <option value="">اختر التصنيف</option>
                {TAGS.filter(t => t !== 'الكل').map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setNewPostModal(false)}>إلغاء</Button>
              <Button onClick={handleNewPost} disabled={!newTitle.trim() || !newBody.trim()}>نشر</Button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  )
}
